(() => {
  const body = document.body;
  const sidebar = document.querySelector('#sidebar');
  const menuButton = document.querySelector('[data-menu-toggle]');
  menuButton?.addEventListener('click', () => {
    const open = body.classList.toggle('menu-open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? (menuButton.dataset.menuCloseLabel || 'Close menu') : (menuButton.dataset.menuOpenLabel || 'Open menu'));
  });
  sidebar?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => body.classList.remove('menu-open')));

  document.querySelectorAll('[data-dismiss-notice]').forEach(button => {
    button.addEventListener('click', () => button.closest('.notice')?.remove());
  });
  document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });

  let dirty = false;
  document.querySelectorAll('form[data-guard-unsaved]').forEach(form => {
    form.addEventListener('input', () => { dirty = true; });
    form.addEventListener('change', () => { dirty = true; });
    form.addEventListener('submit', () => { dirty = false; });
  });
  window.addEventListener('beforeunload', event => {
    if (!dirty) return;
    event.preventDefault();
    event.returnValue = '';
  });

  const addLine = document.querySelector('[data-add-line]');
  addLine?.addEventListener('click', () => {
    const total = document.querySelector('#id_lines-TOTAL_FORMS');
    const template = document.querySelector('#empty-line-form');
    const container = document.querySelector('[data-formset-container]');
    if (!total || !template || !container) return;
    const index = Number(total.value);
    const wrapper = document.createElement('div');
    wrapper.innerHTML = template.innerHTML.replaceAll('__prefix__', String(index));
    const row = wrapper.firstElementChild;
    row.querySelector('[data-line-number]')?.replaceChildren(document.createTextNode(String(index + 1)));
    container.appendChild(row);
    total.value = String(index + 1);
    dirty = true;
    row.querySelector('input:not([type=hidden])')?.focus();
  });

  const interval = Number(body.dataset.autoRefresh);
  const stateUrl = body.dataset.stateUrl;
  let revision = body.dataset.revision || '0:0';
  const indicator = document.querySelector('[data-sync-indicator]');
  const indicatorLabel = document.querySelector('[data-sync-label]');
  let updateAvailable = false;

  function showUpdate() {
    if (!indicator || updateAvailable) return;
    updateAvailable = true;
    indicator.hidden = false;
    indicator.classList.add('sync-action');
    if (indicatorLabel) indicatorLabel.textContent = body.dataset.updateLabel || 'Update available · Refresh';
    indicator.setAttribute('role', 'button');
    indicator.setAttribute('tabindex', '0');
    indicator.addEventListener('click', () => location.reload(), { once: true });
    indicator.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); location.reload(); }
    }, { once: true });
  }

  async function checkUpdate() {
    if (!interval || !stateUrl || document.hidden) return;
    try {
      const response = await fetch(stateUrl, { credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json' } });
      if (!response.ok) return;
      const data = await response.json();
      const next = String(data.revision || '0:0');
      if (next !== revision) {
        const activeFilter = document.activeElement?.closest?.('.auto-refresh-guard');
        if (dirty || activeFilter) showUpdate();
        else location.reload();
      }
    } catch (_) { /* Stay on the current page if the network is unavailable. */ }
  }

  if (interval && stateUrl) {
    window.setInterval(checkUpdate, Math.max(interval, 5000));
    window.addEventListener('focus', checkUpdate);
  }
})();
