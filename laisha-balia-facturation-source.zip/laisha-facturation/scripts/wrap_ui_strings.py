"""One-time source rewrite for literal template labels in the UI catalog."""

import json
import re
from pathlib import Path

from billing.i18n_ui import TEXT


root = Path(__file__).resolve().parents[1] / "templates"
count = 0
for path in root.rglob("*.html"):
    source = path.read_text()
    if path.name != "base.html" and "{% load i18n_ui %}" not in source:
        source = re.sub(r"(\{% extends [^\n]+%\})", r"\1\n{% load i18n_ui %}", source, count=1)

    def replace(match):
        global count
        segment = match.group(1)
        if "{{" in segment or "{%" in segment:
            return match.group(0)
        key = segment.strip()
        if key not in TEXT:
            return match.group(0)
        count += 1
        leading = segment[:len(segment) - len(segment.lstrip())]
        trailing = segment[len(segment.rstrip()):]
        return ">" + leading + "{% tr " + json.dumps(key, ensure_ascii=False) + " %}" + trailing + "<"

    source = re.sub(r">([^<>]+)<", replace, source)
    def replace_block(match):
        value = match.group(2).strip()
        if value not in TEXT:
            return match.group(0)
        return match.group(1) + "{% tr " + json.dumps(value, ensure_ascii=False) + " %}" + match.group(3)

    source = re.sub(r"(\{% block (?:title|topbar_title) %\})([^{}]+)(\{% endblock %\})", replace_block, source)
    for raw, translated in {
        "{{ field.label }}": "{{ field.label|tr }}",
        "{{ document.get_kind_display }}": "{{ document.get_kind_display|tr }}",
        "{{ document.get_kind_display|upper }}": "{{ document.get_kind_display|tr|upper }}",
        "{{ document.get_kind_display|lower }}": "{{ document.get_kind_display|tr|lower }}",
        "{{ document.get_status_display }}": "{{ document.get_status_display|tr }}",
        "{{ document.payment_status }}": "{{ document.payment_status|tr }}",
        "{{ expense.get_status_display }}": "{{ expense.get_status_display|tr }}",
        "{{ payment.get_method_display|default:payment.method }}": "{{ payment.get_method_display|tr|default:payment.method }}",
        "{{ event.get_action_display|default:event.action }}": "{{ event.get_action_display|tr|default:event.action }}",
        "{{ item.account.get_kind_display }}": "{{ item.account.get_kind_display|tr }}",
        "{{ title }}": "{{ title|tr }}",
    }.items():
        source = source.replace(raw, translated)
    path.write_text(source)

print(f"Wrapped {count} static labels")
