# LAISHA GLOBAL / BALIA GLOBAL — Facturation et finances

Application web partagée pour les deux sociétés. Chaque employé se connecte avec un compte créé dans l'application, sans compte ChatGPT. Les données sont enregistrées dans une base commune ; les écrans ouverts détectent les modifications de facturation et de finance des autres employés. Un sélecteur permet de changer de société ; les clients, documents, numéros, paiements, dépenses et rapports sont séparés par société.

## Fonctions

- Clients, devis, proformas, factures et avoirs.
- Brouillons modifiables, émission avec numéros uniques, documents émis verrouillés.
- Paiements partiels, solde restant et suivi des échéances. Un administrateur peut annuler un paiement erroné avec un motif ; l'écriture originale et son annulation restent dans l'historique.
- Tableau des paiements reçus sur l'accueil et détail par client et facture : montant facturé, encaissements, avoirs, solde à encaisser et trop perçu, séparés par devise et par société.
- PDF de chaque document avec le logo et son filigrane propres à la société ; exports CSV et archive JSON des données de chaque société.
- Interface et libellés des PDF en anglais, français, arabe et chinois simplifié. Les données saisies (noms, descriptions, conditions) restent telles qu'elles ont été entrées ; l'arabe utilise une disposition de droite à gauche.
- Suivi financier par société : catégories de dépenses, comptes banque/caisse/Mobile Money, entrées de fonds avec provenance et référence, brouillons et validation des dépenses, annulations tracées, entrées et sorties de trésorerie, soldes par compte et exports comptables. Les montants USD et LRD restent séparés. Les paiements de factures affectés à un compte sont déjà comptés dans son solde et ne doivent pas être saisis une seconde fois comme entrée de fonds.
- Accès selon le rôle : responsable pour l'émission, les paramètres et les exports de facturation ; comptable ou responsable pour les finances ; employés pour les brouillons, clients et paiements autorisés.
- Historique des changements et détection des modifications simultanées.
- Paramètres de l'entreprise et de la taxe ; aucun taux n'est appliqué automatiquement.

Le volet financier est un livre de trésorerie et un registre des dépenses. Il ne produit pas encore de comptabilité en partie double, de rapprochement bancaire ou de déclaration fiscale prête à déposer.

Pour enregistrer une somme reçue hors facture, créer d'abord un compte dans **Finances → Comptes et catégories**, puis utiliser **Finances → Ajouter des fonds**. La somme apparaît dans le solde de ce compte et dans le livre de trésorerie de la société active. Une erreur se corrige par annulation motivée, qui conserve la trace de l'entrée. Les paiements de factures déjà affectés à un compte augmentent son solde automatiquement ; ne pas les ajouter une deuxième fois.

## Démarrage local

Python 3.12 est recommandé. Dans ce dossier :

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python manage.py migrate
.venv/bin/python manage.py createsuperuser
.venv/bin/python manage.py runserver
```

Ouvrir ensuite `http://127.0.0.1:8000/`. L'administrateur crée les comptes employés et attribue à chacun un rôle pour chaque société dans `/admin/` via les appartenances aux sociétés. L'installation locale utilise SQLite uniquement pour la préparation et les essais sur cet ordinateur ; les employés distants doivent utiliser le déploiement avec PostgreSQL.

## Avant la première vraie facture

1. Compléter séparément les coordonnées légales, le numéro d'enregistrement fiscal et les mentions de paiement de LAISHA GLOBAL et de BALIA GLOBAL dans leurs paramètres. L'adresse de BALIA GLOBAL n'est pas préremplie ; l'émission d'une vraie facture attend ces données.
2. Déterminer avec la LRA ou un conseiller local le statut fiscal de l'entreprise et le traitement de chaque activité facturée. L'application ne décide pas seule si une opération est soumise à la GST, exonérée ou hors champ.
3. Vérifier les anciens numéros de factures de chaque société avant la première émission pour éviter les doublons avec des documents déjà émis. Les nouveaux préfixes sont LG et BG.
4. Créer les clients, puis préparer et contrôler chaque brouillon avant son émission. Une correction après émission passe par un avoir ; le document original est conservé.
5. Mettre en place une sauvegarde régulière de la base PostgreSQL et la conserver selon la politique d'archivage de l'entreprise. L'archive JSON de l'application sert à consulter les données, mais ne contient pas les comptes employés et ne constitue pas une sauvegarde restaurable. Le Code des recettes libérien prévoit une conservation de sept ans après la période fiscale pertinente.

Les PDF produits par cette application ne sont pas présentés comme des factures électroniques certifiées par la LRA. Si la LRA a attribué un appareil fiscal à l'une des sociétés, son utilisation doit être vérifiée séparément.

## Mise en ligne

Le fichier `render.yaml` prépare un service web Python et une base PostgreSQL payante dans la même région, avec la base fermée aux connexions publiques. Pour l'utiliser, placer ce dossier dans un dépôt Git privé contrôlé par le propriétaire des deux sociétés, connecter le dépôt au compte Render de l'entreprise, puis créer un Blueprint à partir du fichier. Render fournit HTTPS et un sous-domaine ; un nom de domaine personnalisé reste facultatif.

Après le premier déploiement, créer l'administrateur depuis le shell du service avec `python manage.py createsuperuser`, puis configurer l'entreprise et les employés. Ne pas partager le compte administrateur. Garder des sauvegardes PostgreSQL indépendantes et tester leur restauration ; les sauvegardes courtes de l'hébergeur ne remplacent pas l'archivage sur sept ans.

Cette installation n'est pas encore publiée. Le déploiement exige un compte Render, un dépôt Git et la validation des frais d'hébergement par le propriétaire.

Sources : [Code des recettes libérien, articles 55, 1022 et 1028](https://revenue.lra.gov.lr/wp-content/uploads/2021/08/REVENUE-CODE-LIBERIA-REVENUE-CODE-AMENDEMENT-2020-min.pdf), [amendement fiscal publié en 2026](https://revenue.lra.gov.lr/wp-content/uploads/2026/04/LRC-Amendment-December-2025.pdf), [annonce de la transition vers la TVA](https://revenue.lra.gov.lr/lra-commits-to-deepening-partnership-with-civil-society-on-revenue-mobilization/), [documentation de déploiement Render](https://render.com/docs/deploy-django).
