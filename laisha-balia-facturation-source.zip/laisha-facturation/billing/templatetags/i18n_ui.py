from django import template

from billing.i18n_ui import translate_ui


register = template.Library()


@register.simple_tag(name="tr")
def translate_tag(value):
    return translate_ui(value)


@register.filter(name="tr")
def translate_filter(value):
    return translate_ui(value)
