from django import forms
from .i18n_ui import translate_ui as tr

from django.forms import inlineformset_factory

from .form_localization import localize_form
from .models import Client, CompanySettings, Document, DocumentLine, Payment


class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ["name", "contact_name", "email", "phone", "address", "tax_id", "notes"]
        widgets = {"address": forms.Textarea(attrs={"rows": 3}), "notes": forms.Textarea(attrs={"rows": 3})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        localize_form(self)


class DocumentForm(forms.ModelForm):
    version = forms.IntegerField(widget=forms.HiddenInput(), required=False)

    class Meta:
        model = Document
        fields = ["client", "title", "reference", "issue_date", "service_date", "due_date", "currency", "tax_treatment", "tax_name", "tax_rate", "related_invoice", "notes", "terms"]
        widgets = {
            "issue_date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "service_date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "due_date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "notes": forms.Textarea(attrs={"rows": 3}),
            "terms": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, kind=None, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.kind = kind or self.instance.kind
        if company is not None:
            self.fields["client"].queryset = Client.objects.filter(company=company)
        self.fields["related_invoice"].queryset = Document.objects.filter(company=company, kind=Document.Kind.INVOICE, status=Document.Status.ISSUED).order_by("-issue_date", "-id")
        if self.kind != Document.Kind.CREDIT_NOTE:
            self.fields.pop("related_invoice")
        if self.instance.pk and not self.is_bound:
            self.initial["version"] = self.instance.version
        localize_form(self)

    def clean(self):
        data = super().clean()
        if self.kind == Document.Kind.CREDIT_NOTE and not data.get("related_invoice"):
            self.add_error("related_invoice", tr("Choisissez la facture concernée."))
        return data


class DocumentLineForm(forms.ModelForm):
    class Meta:
        model = DocumentLine
        fields = ["description", "quantity", "unit_price"]
        widgets = {"description": forms.TextInput(attrs={"placeholder": "Description du bien ou service"})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.instance.pk:
            self.initial["quantity"] = None
            self.initial["unit_price"] = None
        localize_form(self)


DocumentLineFormSet = inlineformset_factory(
    Document, DocumentLine, form=DocumentLineForm,
    fields=["description", "quantity", "unit_price"], extra=3, can_delete=True,
)


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ["amount", "received_on", "method", "account", "reference", "notes"]
        widgets = {
            "received_on": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, document=None, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        if document is not None:
            self.fields["account"].queryset = self.fields["account"].queryset.filter(company=company or document.company, currency=document.currency, active=True)
        self.fields["account"].help_text = "Sélectionnez le compte qui a reçu les fonds pour le suivi de trésorerie."
        localize_form(self)


class CompanySettingsForm(forms.ModelForm):
    class Meta:
        model = CompanySettings
        fields = ["name", "address", "email", "phone", "tax_id", "website", "default_currency", "payment_details", "footer_note"]
        widgets = {"address": forms.Textarea(attrs={"rows": 3}), "payment_details": forms.Textarea(attrs={"rows": 3}), "footer_note": forms.Textarea(attrs={"rows": 3})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        localize_form(self)
