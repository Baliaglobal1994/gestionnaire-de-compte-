from django.conf import settings
from django.db import migrations


def seed_companies(apps, schema_editor):
    Company = apps.get_model("billing", "CompanySettings")
    Membership = apps.get_model("billing", "CompanyMembership")
    Client = apps.get_model("billing", "Client")
    Document = apps.get_model("billing", "Document")
    Sequence = apps.get_model("billing", "NumberSequence")
    Audit = apps.get_model("billing", "AuditEvent")
    Account = apps.get_model("finance", "CashAccount")
    Category = apps.get_model("finance", "ExpenseCategory")
    Expense = apps.get_model("finance", "Expense")
    Event = apps.get_model("finance", "FinanceEvent")
    User = apps.get_model(*settings.AUTH_USER_MODEL.split("."))

    laisha = Company.objects.order_by("pk").first()
    if laisha is None:
        laisha = Company.objects.create(name="LAISHA GLOBAL", slug="laisha-global", document_prefix="LG")
    else:
        laisha.name = laisha.name or "LAISHA GLOBAL"
        laisha.slug = "laisha-global"
        laisha.document_prefix = "LG"
        laisha.save(update_fields=["name", "slug", "document_prefix"])
    balia, _ = Company.objects.get_or_create(
        slug="balia-global",
        defaults={"name": "BALIA GLOBAL", "document_prefix": "BG"},
    )

    for model in (Client, Document, Sequence, Audit, Account, Category, Expense, Event):
        model.objects.filter(company__isnull=True).update(company_id=laisha.pk)

    for user in User.objects.all():
        role = "manager" if user.is_staff or user.is_superuser else "employee"
        Membership.objects.get_or_create(company_id=laisha.pk, user_id=user.pk, defaults={"role": role})
        if user.is_superuser:
            Membership.objects.get_or_create(company_id=balia.pk, user_id=user.pk, defaults={"role": "manager"})


class Migration(migrations.Migration):
    dependencies = [
        ("billing", "0004_companymembership_and_more"),
        ("finance", "0002_remove_cashaccount_unique_cash_account_currency_and_more"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [migrations.RunPython(seed_companies, migrations.RunPython.noop)]
