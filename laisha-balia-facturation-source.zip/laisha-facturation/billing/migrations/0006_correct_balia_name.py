from django.db import migrations


def correct_name(apps, schema_editor):
    Company = apps.get_model("billing", "CompanySettings")
    Company.objects.filter(slug="mbaolia-global").update(
        name="BALIA GLOBAL", slug="balia-global", document_prefix="BG"
    )


class Migration(migrations.Migration):
    dependencies = [("billing", "0005_seed_companies")]
    operations = [migrations.RunPython(correct_name, migrations.RunPython.noop)]
