from django.urls import path

from . import views


urlpatterns = [
    path("company/switch/", views.switch_company, name="switch_company"),
    path("language/switch/", views.switch_language, name="switch_language"),
    path("", views.dashboard, name="dashboard"),
    path("clients/", views.client_list, name="client_list"),
    path("payments/received/", views.payments_received, name="payments_received"),
    path("clients/new/", views.client_new, name="client_new"),
    path("clients/<int:pk>/edit/", views.client_edit, name="client_edit"),
    path("documents/", views.document_list, name="document_list"),
    path("documents/new/<str:kind>/", views.document_new, name="document_new"),
    path("documents/<int:pk>/", views.document_detail, name="document_detail"),
    path("documents/<int:pk>/edit/", views.document_edit, name="document_edit"),
    path("documents/<int:pk>/issue/", views.document_issue, name="document_issue"),
    path("documents/<int:pk>/pdf/", views.document_pdf, name="document_pdf"),
    path("documents/<int:pk>/payments/new/", views.payment_new, name="payment_new"),
    path("payments/<int:pk>/reverse/", views.payment_reverse, name="payment_reverse"),
    path("settings/company/", views.company_settings, name="company_settings"),
    path("export/<str:kind>/", views.export_data, name="export"),
    path("state/", views.state, name="state"),
    path("health/", views.health, name="health"),
]
