from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse

from .models import AuditEvent, Client, CompanyMembership, CompanySettings, Document, DocumentLine, PaymentReversal
from .services import issue_document, record_payment, reverse_payment


class BillingFlowTests(TestCase):
    def setUp(self):
        users = get_user_model()
        self.admin = users.objects.create_superuser("owner", "owner@example.test", "strong-test-password")
        self.employee = users.objects.create_user("employee", "employee@example.test", "strong-test-password")
        self.company = CompanySettings.objects.get(slug="laisha-global")
        self.company.address = "Monrovia, Liberia"
        self.company.tax_id = "TEST-TIN"
        self.company.payment_details = "Bank transfer"
        self.company.save()
        CompanyMembership.objects.create(company=self.company, user=self.employee, role=CompanyMembership.Role.EMPLOYEE)
        self.client_record = Client.objects.create(company=self.company, name="Test Client", address="Monrovia")

    def invoice(self, *, treatment=Document.TaxTreatment.TAXABLE):
        doc = Document.objects.create(
            kind=Document.Kind.INVOICE,
            company=self.company,
            client=self.client_record,
            created_by=self.employee,
            issue_date=date(2026, 10, 2),
            service_date=date(2026, 10, 1),
            currency="USD",
            tax_treatment=treatment,
            tax_name="GST" if treatment == Document.TaxTreatment.TAXABLE else "",
            tax_rate=Decimal("13.00") if treatment == Document.TaxTreatment.TAXABLE else Decimal("0.00"),
        )
        DocumentLine.objects.create(document=doc, description="Service", quantity=Decimal("2.00"), unit_price=Decimal("10.00"))
        return doc

    def test_number_snapshot_payment_and_immutability(self):
        draft = self.invoice()
        stale_line = draft.lines.first()
        doc = issue_document(draft.pk, self.admin)
        self.assertEqual(doc.number, "LG-FAC-2026-0001")
        self.assertEqual(doc.amount_total, Decimal("22.60"))
        self.client_record.name = "Renamed Client"
        self.client_record.save()
        self.assertEqual(doc.client_name_snapshot, "Test Client")
        self.client.force_login(self.admin)
        detail = self.client.get(reverse("document_detail", args=[doc.pk]))
        self.assertEqual(detail.context["display_client_name"], "Test Client")
        self.assertIn(b"Test Client", self.client.get(reverse("export", args=["documents"])).content)
        payment = record_payment(doc.pk, amount=Decimal("5.00"), received_on=date(2026, 10, 2), method="bank", reference="T1", notes="", actor=self.employee)
        doc.refresh_from_db()
        self.assertEqual(doc.balance, Decimal("17.60"))
        with self.assertRaises(ValidationError):
            record_payment(doc.pk, amount=Decimal("18.00"), received_on=date(2026, 10, 2), method="bank", reference="T2", notes="", actor=self.employee)
        with self.assertRaises(ValidationError):
            doc.save()
        with self.assertRaises(ValidationError):
            draft.delete()
        stale_line.description = "Changed after issue"
        with self.assertRaises(ValidationError):
            stale_line.save()
        with self.assertRaises(ValidationError):
            stale_line.delete()
        with self.assertRaises(ValidationError):
            payment.delete()
        second = issue_document(self.invoice().pk, self.admin)
        self.assertEqual(second.number, "LG-FAC-2026-0002")

    def test_tax_choice_is_required_before_issue(self):
        doc = self.invoice(treatment=Document.TaxTreatment.PENDING)
        with self.assertRaises(ValidationError):
            issue_document(doc.pk, self.admin)
        doc.refresh_from_db()
        self.assertEqual(doc.status, Document.Status.DRAFT)
        self.assertIsNone(doc.number)

    def test_invalid_line_cannot_be_issued_even_if_created_outside_form(self):
        doc = self.invoice()
        line = doc.lines.first()
        line.quantity = Decimal("-1.00")
        line.save()
        with self.assertRaises(ValidationError):
            issue_document(doc.pk, self.admin)
        doc.refresh_from_db()
        self.assertEqual(doc.status, Document.Status.DRAFT)

    def test_roles_and_pdf_access(self):
        doc = self.invoice()
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 302)
        self.client.force_login(self.employee)
        self.assertEqual(self.client.get(reverse("dashboard")).status_code, 200)
        self.assertEqual(self.client.get(reverse("company_settings")).status_code, 403)
        self.assertEqual(self.client.post(reverse("document_issue", args=[doc.pk])).status_code, 403)
        self.client.force_login(self.admin)
        response = self.client.post(reverse("document_issue", args=[doc.pk]))
        self.assertEqual(response.status_code, 302)
        pdf = self.client.get(reverse("document_pdf", args=[doc.pk]))
        self.assertEqual(pdf.status_code, 200)
        self.assertEqual(pdf["Content-Type"], "application/pdf")
        self.assertTrue(pdf.content.startswith(b"%PDF"))

    def test_four_language_pdf_and_finance_refresh_revision(self):
        from finance.models import FinanceEvent

        doc = issue_document(self.invoice().pk, self.admin)
        self.client.force_login(self.admin)
        initial_revision = self.client.get(reverse("state")).json()["revision"]
        for language in ("en", "fr", "ar", "zh-hans"):
            self.assertEqual(self.client.post(reverse("switch_language"), {"language": language}).status_code, 302)
            dashboard = self.client.get(reverse("dashboard"))
            self.assertEqual(dashboard.status_code, 200)
            self.assertContains(dashboard, f'lang="{language}"')
            self.assertEqual(dashboard.context["app_revision"], initial_revision)
            pdf = self.client.get(reverse("document_pdf", args=[doc.pk]))
            self.assertEqual(pdf.status_code, 200)
            self.assertTrue(pdf.content.startswith(b"%PDF"))
            self.assertGreater(len(pdf.content), 1000)
        FinanceEvent.objects.create(company=self.company, actor=self.admin, action="test_finance_change")
        self.assertNotEqual(self.client.get(reverse("state")).json()["revision"], initial_revision)

    def test_employee_creates_draft_and_stale_edit_is_rejected(self):
        self.client.force_login(self.employee)
        payload = {
            "client": self.client_record.pk,
            "title": "Design service",
            "reference": "",
            "issue_date": "2026-10-02",
            "service_date": "2026-10-02",
            "due_date": "",
            "currency": "USD",
            "tax_treatment": "pending",
            "tax_name": "",
            "tax_rate": "0.00",
            "notes": "",
            "terms": "",
            "version": "",
            "lines-TOTAL_FORMS": "3",
            "lines-INITIAL_FORMS": "0",
            "lines-MIN_NUM_FORMS": "0",
            "lines-MAX_NUM_FORMS": "1000",
            "lines-0-description": "Concept design",
            "lines-0-quantity": "1.00",
            "lines-0-unit_price": "100.00",
            "lines-1-description": "",
            "lines-1-quantity": "",
            "lines-1-unit_price": "",
            "lines-2-description": "",
            "lines-2-quantity": "",
            "lines-2-unit_price": "",
        }
        response = self.client.post(reverse("document_new", args=["invoice"]), payload)
        self.assertEqual(response.status_code, 302)
        doc = Document.objects.get(title="Design service")
        self.assertEqual(doc.lines.count(), 1)
        stale_version = doc.version
        doc.title = "Edited elsewhere"
        doc.version += 1
        doc.save()
        payload.update({"version": str(stale_version), "title": "Old edit", "lines-INITIAL_FORMS": "1", "lines-0-id": str(doc.lines.first().pk)})
        response = self.client.post(reverse("document_edit", args=[doc.pk]), payload)
        self.assertEqual(response.status_code, 200)
        doc.refresh_from_db()
        self.assertEqual(doc.title, "Edited elsewhere")

    def test_csv_export_neutralizes_spreadsheet_formulas(self):
        Client.objects.create(company=self.company, name='=HYPERLINK("https://example.test", "Click")')
        self.client.force_login(self.employee)
        self.assertEqual(self.client.get(reverse("export", args=["clients"])).status_code, 403)
        self.client.force_login(self.admin)
        response = self.client.get(reverse("export", args=["clients"]))
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"'=HYPERLINK", response.content)

    def test_payment_reversal_requires_admin_reason_and_restores_balance(self):
        doc = issue_document(self.invoice().pk, self.admin)
        payment = record_payment(doc.pk, amount=Decimal("5.00"), received_on=date(2026, 10, 2), method="bank", reference="T1", notes="", actor=self.employee)
        url = reverse("payment_reverse", args=[payment.pk])
        self.client.force_login(self.employee)
        self.assertEqual(self.client.post(url, {"reason": "Entered twice"}).status_code, 403)
        self.client.force_login(self.admin)
        self.assertEqual(self.client.post(url, {"reason": " "}).status_code, 302)
        self.assertFalse(payment.is_reversed)
        self.assertEqual(self.client.post(url, {"reason": "Entered twice"}).status_code, 302)
        payment.refresh_from_db()
        doc.refresh_from_db()
        self.assertTrue(payment.is_reversed)
        self.assertEqual(doc.amount_paid, Decimal("0.00"))
        self.assertEqual(doc.balance, doc.amount_total)
        self.assertEqual(PaymentReversal.objects.count(), 1)
        self.assertEqual(AuditEvent.objects.get(action="payment_reversed").get_action_display(), "Paiement annulé")
        events = list(self.client.get(reverse("document_detail", args=[doc.pk])).context["audit_events"])
        self.assertIn("payment_recorded", [event.action for event in events])
        self.assertIn("payment_reversed", [event.action for event in events])
        self.assertEqual(self.client.post(url, {"reason": "Again"}).status_code, 302)
        self.assertEqual(PaymentReversal.objects.count(), 1)
        csv_data = self.client.get(reverse("export", args=["payments"])).content
        self.assertIn(b"Entered twice", csv_data)

    def test_company_switch_separates_clients_documents_and_numbering(self):
        other = CompanySettings.objects.get(slug="balia-global")
        other.address = "Monrovia, Liberia"
        other.save()
        other_client = Client.objects.create(company=other, name="Balia Client")
        other_doc = Document.objects.create(
            company=other, kind=Document.Kind.INVOICE, client=other_client, created_by=self.admin,
            issue_date=date(2026, 10, 2), currency="USD", tax_treatment=Document.TaxTreatment.OUT_OF_SCOPE,
        )
        DocumentLine.objects.create(document=other_doc, description="Other company service", quantity=1, unit_price=25)
        other_doc = issue_document(other_doc.pk, self.admin)
        first_doc = issue_document(self.invoice(treatment=Document.TaxTreatment.OUT_OF_SCOPE).pk, self.admin)
        self.assertEqual(other_doc.number, "BG-FAC-2026-0001")
        self.assertEqual(first_doc.number, "LG-FAC-2026-0001")
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get(reverse("document_detail", args=[other_doc.pk])).status_code, 404)
        self.assertNotContains(self.client.get(reverse("document_list")), "Balia Client")
        self.assertEqual(self.client.post(reverse("switch_company"), {"company_id": other.pk}).status_code, 302)
        self.assertContains(self.client.get(reverse("document_list")), "Balia Client")
        self.assertEqual(self.client.get(reverse("document_detail", args=[first_doc.pk])).status_code, 404)
        self.assertNotIn(b"Test Client", self.client.get(reverse("export", args=["clients"])).content)
        self.client.force_login(self.employee)
        self.assertEqual(self.client.post(reverse("switch_company"), {"company_id": other.pk}).status_code, 404)

    def test_payments_received_report_and_overview_are_company_and_currency_scoped(self):
        def issued(company, client, amount, currency="USD"):
            document = Document.objects.create(
                company=company, kind=Document.Kind.INVOICE, client=client,
                created_by=self.admin, issue_date=date(2026, 10, 2), currency=currency,
                tax_treatment=Document.TaxTreatment.OUT_OF_SCOPE,
            )
            DocumentLine.objects.create(document=document, description="Service", quantity=1, unit_price=amount)
            return issue_document(document.pk, self.admin)

        first = issued(self.company, self.client_record, "20.00")
        local = issued(self.company, self.client_record, "100.00", "LRD")
        second_client = Client.objects.create(company=self.company, name="Second Client")
        second = issued(self.company, second_client, "30.00")
        self.invoice(treatment=Document.TaxTreatment.OUT_OF_SCOPE)  # Draft does not belong in receivables.
        first_payment = record_payment(first.pk, amount=Decimal("5.00"), received_on=date(2026, 10, 2), method="bank", reference="A", notes="", actor=self.employee)
        reversed_payment = record_payment(first.pk, amount=Decimal("4.00"), received_on=date(2026, 10, 2), method="bank", reference="B", notes="", actor=self.employee)
        reverse_payment(reversed_payment.pk, reason="Duplicate", actor=self.admin)
        record_payment(local.pk, amount=Decimal("25.00"), received_on=date(2026, 10, 2), method="bank", reference="C", notes="", actor=self.employee)

        credit = Document.objects.create(
            company=self.company, kind=Document.Kind.CREDIT_NOTE, client=second_client,
            related_invoice=second, created_by=self.admin, issue_date=date(2026, 10, 2),
            currency="USD", tax_treatment=Document.TaxTreatment.OUT_OF_SCOPE,
        )
        DocumentLine.objects.create(document=credit, description="Credit", quantity=1, unit_price="10.00")
        issue_document(credit.pk, self.admin)

        balia = CompanySettings.objects.get(slug="balia-global")
        balia.address = "Monrovia, Liberia"
        balia.save()
        balia_client = Client.objects.create(company=balia, name="Balia Client")
        balia_invoice = issued(balia, balia_client, "40.00")
        record_payment(balia_invoice.pk, amount=Decimal("11.00"), received_on=date(2026, 10, 2), method="bank", reference="D", notes="", actor=self.admin)

        self.assertEqual(self.client.get(reverse("payments_received")).status_code, 302)
        self.client.force_login(self.employee)
        response = self.client.get(reverse("payments_received"))
        self.assertEqual(response.status_code, 200)
        totals = {row["currency"]: row for row in response.context["payment_currencies"]}
        self.assertEqual(set(totals), {"USD", "LRD"})
        self.assertEqual(totals["USD"]["invoiced_total"], Decimal("50.00"))
        self.assertEqual(totals["USD"]["received_total"], first_payment.amount)
        self.assertEqual(totals["USD"]["credited_total"], Decimal("10.00"))
        self.assertEqual(totals["USD"]["balance_total"], Decimal("35.00"))
        self.assertEqual(totals["LRD"]["received_total"], Decimal("25.00"))
        self.assertEqual(totals["LRD"]["balance_total"], Decimal("75.00"))
        clients = response.context["payment_clients"]
        self.assertEqual(len(clients), 2)
        first_rows = [row for group in clients for row in group["invoices"] if row["document"].pk == first.pk]
        self.assertEqual(first_rows[0]["received_total"], Decimal("5.00"))
        self.assertEqual(first_rows[0]["balance"], Decimal("15.00"))
        self.assertNotContains(response, "Balia Client")
        dashboard = self.client.get(reverse("dashboard"))
        self.assertEqual(dashboard.context["payment_currencies"], response.context["payment_currencies"])

        self.client.force_login(self.admin)
        self.client.post(reverse("switch_company"), {"company_id": balia.pk})
        balia_report = self.client.get(reverse("payments_received"))
        balia_totals = balia_report.context["payment_currencies"]
        self.assertEqual(len(balia_totals), 1)
        self.assertEqual(balia_totals[0]["received_total"], Decimal("11.00"))
        self.assertEqual(balia_totals[0]["balance_total"], Decimal("29.00"))
        self.assertEqual(len(balia_report.context["payment_clients"]), 1)
        self.assertEqual(balia_report.context["payment_clients"][0]["client"].pk, balia_client.pk)
        self.assertEqual(self.client.get(reverse("dashboard")).context["payment_currencies"], balia_totals)
