"""Company-scoped change token for pages shared by billing and finance."""

from finance.models import FinanceEvent

from .models import AuditEvent


def company_revision(company):
    if company is None:
        return "0:0"
    billing = AuditEvent.objects.filter(company=company).order_by("-pk").values_list("pk", flat=True).first() or 0
    finance = FinanceEvent.objects.filter(company=company).order_by("-pk").values_list("pk", flat=True).first() or 0
    return f"{billing}:{finance}"
