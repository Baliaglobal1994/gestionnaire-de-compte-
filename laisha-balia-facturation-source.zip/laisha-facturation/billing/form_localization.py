"""Translate fixed form chrome while preserving user-entered company data."""

from django import forms

from .i18n_ui import translate_ui


def localize_form(form):
    for field in form.fields.values():
        if field.label:
            field.label = translate_ui(field.label)
        if field.help_text:
            field.help_text = translate_ui(field.help_text)
        placeholder = field.widget.attrs.get("placeholder")
        if placeholder:
            field.widget.attrs["placeholder"] = translate_ui(placeholder)
        if isinstance(field, forms.ChoiceField) and not isinstance(field, forms.ModelChoiceField):
            field.choices = [(value, translate_ui(label)) for value, label in field.choices]
