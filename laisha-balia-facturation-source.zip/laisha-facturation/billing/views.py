"""Authenticated billing workflow. Issued documents are never edited in place."""

import csv
import json
from collections import defaultdict
from datetime import date
from decimal import Decimal
from functools import wraps

from .i18n_ui import translate_ui as tr

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Q
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST
from django.utils import timezone

from .company_context import allowed_companies
from .language import SUPPORTED_LANGUAGES
from .forms import ClientForm, CompanySettingsForm, DocumentForm, DocumentLineFormSet, PaymentForm
from .models import AuditEvent, Client, CompanySettings, Document, DocumentLine, NumberSequence, Payment, PaymentReversal
from .pdf import render_document_pdf
from .revision import company_revision
from .services import audit, issue_document, record_payment, reverse_payment
from finance.models import CashAccount, CashDeposit, Expense, ExpenseCategory, FinanceEvent


def manager_required(view):
    @login_required
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        if request.company_role != "manager":
            raise PermissionDenied(tr("Accès réservé à un administrateur."))
        return view(request, *args, **kwargs)
    return wrapped


def _documents(company):
    return Document.objects.filter(company=company).select_related("client", "related_invoice").prefetch_related("lines", "payments__reversal", "credit_notes")


def _errors_text(error):
    if hasattr(error, "messages"):
        return " ".join(error.messages)
    return str(error)


def _payment_report(company):
    """Issued invoice receivables, with each currency kept in its own totals.

    Prefetching payments, reversals and credit notes keeps the report usable for
    a growing invoice register. Reversed payments are retained in the ledger,
    but do not count as money received.
    """
    invoices = (
        Document.objects.filter(company=company, kind=Document.Kind.INVOICE, status=Document.Status.ISSUED)
        .select_related("client")
        .prefetch_related("payments__reversal", "credit_notes")
        .order_by("-issue_date", "-id")
    )

    def empty_totals(currency):
        return {
            "currency": currency,
            "invoiced_total": Decimal("0.00"),
            "received_total": Decimal("0.00"),
            "credited_total": Decimal("0.00"),
            "balance_total": Decimal("0.00"),
            "overpaid_total": Decimal("0.00"),
            "invoice_count": 0,
        }

    company_totals = {}
    client_groups = {}
    for document in invoices:
        received = sum((payment.amount for payment in document.payments.all() if not payment.is_reversed), Decimal("0.00"))
        credited = sum(
            (credit.amount_total for credit in document.credit_notes.all() if credit.status == Document.Status.ISSUED),
            Decimal("0.00"),
        )
        invoiced = document.amount_total
        balance = invoiced - received - credited
        invoice_row = {
            "document": document,
            "invoiced_total": invoiced,
            "received_total": received,
            "credited_total": credited,
            "balance": balance,
        }
        group = client_groups.setdefault(document.client_id, {
            "client": document.client, "invoices": [], "_currencies": {},
        })
        group["invoices"].append(invoice_row)
        for totals in (
            company_totals.setdefault(document.currency, empty_totals(document.currency)),
            group["_currencies"].setdefault(document.currency, empty_totals(document.currency)),
        ):
            totals["invoiced_total"] += invoiced
            totals["received_total"] += received
            totals["credited_total"] += credited
            totals["balance_total"] += max(balance, Decimal("0.00"))
            totals["overpaid_total"] += max(-balance, Decimal("0.00"))
            totals["invoice_count"] += 1

    clients = []
    for group in sorted(client_groups.values(), key=lambda value: (value["client"].name.casefold(), value["client"].pk)):
        group["currencies"] = [group["_currencies"][currency] for currency in sorted(group["_currencies"])]
        del group["_currencies"]
        clients.append(group)
    return [company_totals[currency] for currency in sorted(company_totals)], clients


@login_required
@require_POST
def switch_company(request):
    company = get_object_or_404(allowed_companies(request.user), pk=request.POST.get("company_id"))
    request.session["company_id"] = company.pk
    messages.success(request, f"{tr('Société active')} : {company.name}.")
    return redirect("dashboard")


@require_POST
def switch_language(request):
    language = request.POST.get("language", "")
    if language not in SUPPORTED_LANGUAGES:
        raise Http404(tr("Langue inconnue."))
    request.session["ui_language"] = language
    return redirect("dashboard" if request.user.is_authenticated else "login")


@login_required
def dashboard(request):
    docs = list(_documents(request.company))
    balances = defaultdict(Decimal)
    overdue_count = 0
    today = timezone.localdate()
    for doc in docs:
        if doc.kind == Document.Kind.INVOICE and doc.status == Document.Status.ISSUED and doc.balance > 0:
            balances[doc.currency] += doc.balance
            if doc.due_date and doc.due_date < today:
                overdue_count += 1
    unpaid_total = " · ".join(f"{currency} {amount:,.2f}" for currency, amount in sorted(balances.items())) or tr("Aucun solde")
    payment_currencies, _ = _payment_report(request.company)
    return render(request, "billing/dashboard.html", {
        "docs": docs,
        "recent_docs": docs[:10],
        "clients_count": Client.objects.filter(company=request.company).count(),
        "overdue_count": overdue_count,
        "unpaid_total": unpaid_total,
        "payment_currencies": payment_currencies,
    })


@login_required
def payments_received(request):
    payment_currencies, payment_clients = _payment_report(request.company)
    return render(request, "billing/payments_received.html", {
        "payment_currencies": payment_currencies,
        "payment_clients": payment_clients,
    })


@login_required
def client_list(request):
    return render(request, "billing/client_list.html", {"clients": Client.objects.filter(company=request.company)})


@login_required
def client_new(request):
    form = ClientForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            client = form.save(commit=False)
            client.company = request.company
            client.save()
            audit(request.user, "client_created", client, {"name": client.name})
        messages.success(request, tr("Client ajouté."))
        return redirect("client_list")
    return render(request, "billing/client_form.html", {"form": form, "client": None})


@login_required
def client_edit(request, pk):
    client = get_object_or_404(Client, pk=pk, company=request.company)
    form = ClientForm(request.POST or None, instance=client)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            form.save()
            audit(request.user, "client_updated", client, {"name": client.name})
        messages.success(request, tr("Client mis à jour."))
        return redirect("client_list")
    return render(request, "billing/client_form.html", {"form": form, "client": client})


@login_required
def document_list(request):
    documents = _documents(request.company)
    kind = request.GET.get("kind", "")
    status = request.GET.get("status", "")
    search = request.GET.get("search", "").strip()[:120]
    if kind in Document.Kind.values:
        documents = documents.filter(kind=kind)
    if status in Document.Status.values:
        documents = documents.filter(status=status)
    if search:
        documents = documents.filter(Q(number__icontains=search) | Q(title__icontains=search) | Q(client__name__icontains=search) | Q(client_name_snapshot__icontains=search))
    return render(request, "billing/document_list.html", {
        "documents": documents[:300], "kind": kind, "status": status, "search": search,
    })


def _render_document_form(request, *, kind, document=None):
    if kind not in Document.Kind.values:
        raise Http404(tr("Type de document inconnu."))
    if document and document.status != Document.Status.DRAFT:
        raise PermissionDenied(tr("Un document émis est verrouillé."))
    original = document
    if document is None:
        document = Document(kind=kind, created_by=request.user, company=request.company)
        company = request.company
        if company:
            document.currency = company.default_currency
        if kind == Document.Kind.CREDIT_NOTE:
            original_id = request.GET.get("invoice")
            if original_id:
                invoice = Document.objects.filter(pk=original_id, company=request.company, kind=Document.Kind.INVOICE, status=Document.Status.ISSUED).first()
                if invoice:
                    document.client = invoice.client
                    document.related_invoice = invoice
                    document.currency = invoice.currency
                    document.tax_treatment = invoice.tax_treatment
                    document.tax_name = invoice.tax_name
                    document.tax_rate = invoice.tax_rate
    if request.method == "POST":
        form = DocumentForm(request.POST, instance=document, kind=kind, company=request.company)
        formset = DocumentLineFormSet(request.POST, instance=document, prefix="lines")
        if form.is_valid() and formset.is_valid():
            try:
                with transaction.atomic():
                    if original:
                        locked = Document.objects.select_for_update().get(pk=original.pk, company=request.company)
                        if locked.status != Document.Status.DRAFT:
                            raise ValidationError(tr("Ce document a été émis pendant votre modification."))
                        if form.cleaned_data.get("version") != locked.version:
                            raise ValidationError(tr("Ce brouillon a été modifié par un collègue. Rechargez la page avant de réessayer."))
                        document.version = locked.version + 1
                    saved = form.save(commit=False)
                    saved.kind = kind
                    saved.company = request.company
                    saved.created_by = original.created_by if original else request.user
                    if original:
                        saved.version = document.version
                    saved.save()
                    formset.instance = saved
                    formset.save()
                    audit(request.user, "document_updated" if original else "document_created", saved, {"kind": kind})
                messages.success(request, tr("Brouillon enregistré."))
                return redirect("document_detail", pk=saved.pk)
            except ValidationError as error:
                form.add_error(None, _errors_text(error))
    else:
        form = DocumentForm(instance=document, kind=kind, company=request.company)
        formset = DocumentLineFormSet(instance=document, prefix="lines")
    return render(request, "billing/document_form.html", {
        "form": form, "formset": formset, "document": original,
        "kind": kind, "clients": Client.objects.filter(company=request.company),
    })


@login_required
def document_new(request, kind):
    return _render_document_form(request, kind=kind)


@login_required
def document_edit(request, pk):
    document = get_object_or_404(Document, pk=pk, company=request.company)
    return _render_document_form(request, kind=document.kind, document=document)


@login_required
def document_detail(request, pk):
    document = get_object_or_404(_documents(request.company), pk=pk)
    payment_ids = [payment.pk for payment in document.payments.all()]
    audit_events = AuditEvent.objects.filter(company=request.company).filter(
        Q(object_type="Document", object_id=document.pk) |
        Q(object_type="Payment", object_id__in=payment_ids)
    )[:20]
    return render(request, "billing/document_detail.html", {
        "document": document,
        "payments": document.payments.all(),
        "balance": document.balance,
        "audit_events": audit_events,
        "can_issue": request.company_role == "manager",
        "can_reverse_payment": request.company_role == "manager",
        "display_client_name": document.client_name_snapshot if document.status == Document.Status.ISSUED else document.client.name,
        "display_client_address": document.client_address_snapshot if document.status == Document.Status.ISSUED else document.client.address,
        "display_client_tax_id": document.client_tax_id_snapshot if document.status == Document.Status.ISSUED else document.client.tax_id,
    })


@manager_required
@require_POST
def document_issue(request, pk):
    get_object_or_404(Document, pk=pk, company=request.company)
    try:
        document = issue_document(pk, request.user)
        messages.success(request, f"{tr('Document émis sous le numéro')} {document.number}.")
    except (ValidationError, Document.DoesNotExist) as error:
        messages.error(request, _errors_text(error))
    return redirect("document_detail", pk=pk)


@login_required
def document_pdf(request, pk):
    document = get_object_or_404(_documents(request.company), pk=pk)
    pdf = render_document_pdf(document)
    filename = (document.number or f"brouillon-{document.pk}").replace("/", "-") + ".pdf"
    response = HttpResponse(pdf, content_type="application/pdf")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    response["Cache-Control"] = "private, no-store"
    return response


@login_required
def payment_new(request, pk):
    document = get_object_or_404(_documents(request.company), pk=pk)
    if document.kind != Document.Kind.INVOICE or document.status != Document.Status.ISSUED:
        raise PermissionDenied(tr("Les paiements concernent les factures émises."))
    form = PaymentForm(request.POST or None, document=document, company=request.company)
    if request.method == "POST" and form.is_valid():
        try:
            record_payment(document.pk, actor=request.user, **form.cleaned_data)
            messages.success(request, tr("Paiement enregistré."))
            return redirect("document_detail", pk=document.pk)
        except ValidationError as error:
            form.add_error(None, _errors_text(error))
    return render(request, "billing/payment_form.html", {"form": form, "document": document})


@manager_required
@require_POST
def payment_reverse(request, pk):
    payment = get_object_or_404(Payment, pk=pk, document__company=request.company)
    try:
        reverse_payment(pk, reason=request.POST.get("reason", ""), actor=request.user)
        messages.success(request, tr("Paiement annulé ; son montant ne compte plus dans le solde."))
    except ValidationError as error:
        messages.error(request, _errors_text(error))
    return redirect("document_detail", pk=payment.document_id)


@manager_required
def company_settings(request):
    company = request.company
    form = CompanySettingsForm(request.POST or None, instance=company)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            saved = form.save()
            audit(request.user, "company_updated", saved, {"name": saved.name})
        messages.success(request, tr("Paramètres enregistrés."))
        return redirect("company_settings")
    return render(request, "billing/company_settings.html", {"form": form})


def _csv_response(filename, header, rows):
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    response["Cache-Control"] = "private, no-store"
    response.write("\ufeff")
    writer = csv.writer(response)
    writer.writerow(header)
    for row in rows:
        # Spreadsheet programs can execute formulas in exported free-text fields.
        writer.writerow("'" + value if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")) else value for value in row)
    return response


@manager_required
@require_GET
def export_data(request, kind):
    if kind == "clients":
        rows = ((c.id, c.name, c.contact_name, c.email, c.phone, c.address, c.tax_id) for c in Client.objects.filter(company=request.company))
        return _csv_response("laisha-clients.csv", ["ID", "Client", "Contact", "Email", "Phone", "Address", "Tax ID"], rows)
    if kind == "documents":
        rows = []
        for d in _documents(request.company).order_by("id"):
            for line in d.lines.all() or [None]:
                client_name = d.client_name_snapshot if d.status == Document.Status.ISSUED else d.client.name
                rows.append((d.id, d.number or "", d.kind, d.status, d.issue_date, d.service_date or "", d.due_date or "", client_name, d.currency, d.tax_treatment, d.tax_name, d.tax_rate, d.amount_subtotal, d.amount_tax, d.amount_total, line.description if line else "", line.quantity if line else "", line.unit_price if line else "", line.amount if line else ""))
        return _csv_response("laisha-documents.csv", ["ID", "Number", "Type", "Status", "Issue date", "Supply date", "Due date", "Client", "Currency", "Tax treatment", "Tax name", "Tax rate %", "Subtotal", "Tax", "Total", "Line", "Quantity", "Unit price", "Line total"], rows)
    if kind == "payments":
        rows = ((p.id, p.document.number, p.document.client_name_snapshot, p.received_on, p.document.currency, p.amount, p.method, p.reference, p.recorded_by.username, "Yes" if p.is_reversed else "No", p.reversal.reason if p.is_reversed else "", p.reversal.created_at if p.is_reversed else "", p.reversal.reversed_by.username if p.is_reversed else "") for p in Payment.objects.select_related("document", "recorded_by", "reversal", "reversal__reversed_by").filter(document__company=request.company))
        return _csv_response("laisha-payments.csv", ["ID", "Invoice", "Client", "Date", "Currency", "Amount", "Method", "Reference", "Recorded by", "Reversed", "Reversal reason", "Reversed at", "Reversed by"], rows)
    if kind == "backup":
        def model_rows(queryset):
            return list(queryset.values())
        data = {
            "company": model_rows(CompanySettings.objects.filter(pk=request.company.pk)),
            "clients": model_rows(Client.objects.filter(company=request.company)),
            "documents": model_rows(Document.objects.filter(company=request.company)),
            "lines": model_rows(DocumentLine.objects.filter(document__company=request.company)),
            "payments": model_rows(Payment.objects.filter(document__company=request.company)),
            "payment_reversals": model_rows(PaymentReversal.objects.filter(payment__document__company=request.company)),
            "sequences": model_rows(NumberSequence.objects.filter(company=request.company)),
            "audit": model_rows(AuditEvent.objects.filter(company=request.company)),
            "cash_accounts": model_rows(CashAccount.objects.filter(company=request.company)),
            "cash_deposits": model_rows(CashDeposit.objects.filter(company=request.company)),
            "expense_categories": model_rows(ExpenseCategory.objects.filter(company=request.company)),
            "expenses": model_rows(Expense.objects.filter(company=request.company)),
            "finance_events": model_rows(FinanceEvent.objects.filter(company=request.company)),
        }
        response = HttpResponse(json.dumps(data, ensure_ascii=False, default=str, indent=2), content_type="application/json; charset=utf-8")
        response["Content-Disposition"] = 'attachment; filename="laisha-archive-donnees.json"'
        response["Cache-Control"] = "private, no-store"
        return response
    raise Http404(tr("Export inconnu."))


@login_required
@require_GET
def state(request):
    response = JsonResponse({"revision": company_revision(request.company)})
    response["Cache-Control"] = "private, no-store"
    return response


@require_GET
def health(request):
    return HttpResponse("ok", content_type="text/plain")
