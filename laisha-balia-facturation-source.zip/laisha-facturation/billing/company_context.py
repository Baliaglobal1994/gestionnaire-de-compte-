from django.http import HttpResponseForbidden

from .i18n_ui import translate_ui as tr
from .models import CompanyMembership, CompanySettings


def allowed_companies(user):
    if not user.is_authenticated:
        return CompanySettings.objects.none()
    if user.is_superuser:
        return CompanySettings.objects.all()
    return CompanySettings.objects.filter(memberships__user=user).distinct()


def company_role(user, company):
    if not user.is_authenticated or company is None:
        return None
    if user.is_superuser:
        return CompanyMembership.Role.MANAGER
    return CompanyMembership.objects.filter(user=user, company=company).values_list("role", flat=True).first()


class CompanySelectionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.company = None
        request.company_role = None
        if request.user.is_authenticated:
            companies = allowed_companies(request.user)
            selected_id = request.session.get("company_id")
            request.company = companies.filter(pk=selected_id).first() if selected_id else None
            if request.company is None:
                request.company = companies.order_by("pk").first()
                if request.company:
                    request.session["company_id"] = request.company.pk
            request.company_role = company_role(request.user, request.company)
            if request.company is None and not request.path.startswith(("/admin/", "/logout/")):
                return HttpResponseForbidden(tr("Aucune société n'est attribuée à ce compte. Contactez l'administrateur."))
        return self.get_response(request)
