"""Mutations that must be atomic and leave an audit trail."""

from decimal import Decimal

from .i18n_ui import translate_ui as tr

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.utils import timezone

from .models import AuditEvent, CompanyMembership, CompanySettings, Document, NumberSequence, Payment, PaymentReversal, money


NUMBER_PREFIX = {
    Document.Kind.QUOTE: "DEV",
    Document.Kind.PROFORMA: "PRO",
    Document.Kind.INVOICE: "FAC",
    Document.Kind.CREDIT_NOTE: "AVO",
}


def audit(actor, action, obj, details=None):
    company = obj if isinstance(obj, CompanySettings) else (obj.document.company if isinstance(obj, Payment) else obj.company)
    return AuditEvent.objects.create(
        company=company,
        actor=actor,
        action=action,
        object_type=obj.__class__.__name__,
        object_id=obj.pk,
        details=details or {},
    )


class StaleDraftError(ValidationError):
    def __init__(self):
        super().__init__(tr("Ce brouillon a été modifié par un collègue. Rechargez la page avant de réessayer."))


@transaction.atomic
def issue_document(document_id, actor):
    document = Document.objects.select_for_update().select_related("client", "related_invoice").get(pk=document_id)
    if document.status != Document.Status.DRAFT:
        raise ValidationError(tr("Ce document est déjà émis."))
    document.full_clean()
    if document.tax_treatment == Document.TaxTreatment.PENDING:
        raise ValidationError(tr("Choisissez le traitement fiscal avant l'émission."))
    company = document.company
    if not company or not company.address:
        raise ValidationError(tr("Complétez l'adresse de cette société dans les paramètres avant l'émission."))
    if document.tax_treatment == Document.TaxTreatment.TAXABLE and not company.tax_id:
        raise ValidationError(tr("Renseignez l'identifiant fiscal de cette société pour ce document taxable."))
    if document.tax_treatment == Document.TaxTreatment.TAXABLE and not document.service_date:
        raise ValidationError(tr("Indiquez la date de prestation ou de livraison pour ce document taxable."))
    lines = list(document.lines.all())
    if not lines:
        raise ValidationError(tr("Ajoutez au moins une ligne avant l'émission."))
    for line in lines:
        line.full_clean()
    subtotal = money(sum((line.amount for line in lines), Decimal("0")))
    if subtotal <= 0:
        raise ValidationError(tr("Le total doit être supérieur à zéro."))
    tax_amount = money(subtotal * document.tax_rate / Decimal("100"))
    total = subtotal + tax_amount
    if total > Decimal("999999999999.99"):
        raise ValidationError(tr("Le total dépasse la limite autorisée pour un document."))
    if document.kind == Document.Kind.CREDIT_NOTE:
        original = Document.objects.select_for_update().get(pk=document.related_invoice_id)
        previous_credit = original.amount_credited
        if total > original.amount_total - previous_credit:
            raise ValidationError(tr("Le montant des avoirs dépasserait le total de la facture."))
    year = document.issue_date.year
    sequence, _ = NumberSequence.objects.get_or_create(company=company, kind=document.kind, year=year)
    sequence = NumberSequence.objects.select_for_update().get(pk=sequence.pk)
    sequence.last_number += 1
    sequence.save(update_fields=["last_number"])
    number = f"{company.document_prefix}-{NUMBER_PREFIX[document.kind]}-{year}-{sequence.last_number:04d}"
    client = document.client
    Document.objects.filter(pk=document.pk, status=Document.Status.DRAFT).update(
        status=Document.Status.ISSUED,
        number=number,
        issued_at=timezone.now(),
        issued_by=actor,
        updated_at=timezone.now(),
        version=document.version + 1,
        client_name_snapshot=client.name,
        client_address_snapshot=client.address,
        client_email_snapshot=client.email,
        client_tax_id_snapshot=client.tax_id,
        company_name_snapshot=company.name,
        company_address_snapshot=company.address,
        company_email_snapshot=company.email,
        company_phone_snapshot=company.phone,
        company_tax_id_snapshot=company.tax_id,
        company_footer_snapshot=company.footer_note,
        company_payment_snapshot=company.payment_details,
        subtotal_snapshot=subtotal,
        tax_amount_snapshot=tax_amount,
        total_snapshot=total,
    )
    document.refresh_from_db()
    audit(actor, "document_issued", document, {"number": number, "kind": document.kind, "total": str(total), "currency": document.currency, "tax_rate": str(document.tax_rate)})
    return document


@transaction.atomic
def record_payment(document_id, *, amount, received_on, method, reference, notes, actor, account=None):
    document = Document.objects.select_for_update().get(pk=document_id)
    if document.kind != Document.Kind.INVOICE or document.status != Document.Status.ISSUED:
        raise ValidationError(tr("Seules les factures émises peuvent recevoir un paiement."))
    amount = money(amount)
    if amount <= 0 or amount > document.balance:
        raise ValidationError(tr("Le montant doit être positif et ne pas dépasser le solde de la facture."))
    if account is not None and account.currency != document.currency:
        raise ValidationError(tr("La devise du compte doit correspondre à la facture."))
    if account is not None and account.company_id != document.company_id:
        raise ValidationError(tr("Le compte doit appartenir à la société de la facture."))
    payment = Payment.objects.create(
        document=document,
        account=account,
        amount=amount,
        received_on=received_on,
        method=method,
        reference=reference,
        notes=notes,
        recorded_by=actor,
    )
    audit(actor, "payment_recorded", payment, {"document": document.number, "amount": str(amount), "currency": document.currency})
    return payment


@transaction.atomic
def reverse_payment(payment_id, *, reason, actor):
    document_id = Payment.objects.values_list("document_id", flat=True).get(pk=payment_id)
    document = Document.objects.select_for_update().get(pk=document_id)
    if not actor.is_superuser and not CompanyMembership.objects.filter(user=actor, company=document.company, role=CompanyMembership.Role.MANAGER).exists():
        raise PermissionDenied(tr("Seul un administrateur de cette société peut annuler un paiement."))
    payment = Payment.objects.select_for_update().get(pk=payment_id)
    reason = reason.strip()
    if not reason:
        raise ValidationError(tr("Indiquez le motif de l'annulation du paiement."))
    if len(reason) > 500:
        raise ValidationError(tr("Le motif ne peut pas dépasser 500 caractères."))
    if PaymentReversal.objects.filter(payment=payment).exists():
        raise ValidationError(tr("Ce paiement a déjà été annulé."))
    reversal = PaymentReversal.objects.create(payment=payment, reason=reason, reversed_by=actor)
    audit(actor, "payment_reversed", document, {
        "payment_id": payment.pk,
        "amount": str(payment.amount),
        "currency": document.currency,
        "reason": reason,
    })
    return reversal
