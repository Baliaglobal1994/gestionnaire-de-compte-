from django.utils import translation


SUPPORTED_LANGUAGES = {"en", "fr", "ar", "zh-hans"}


class LanguageSelectionMiddleware:
    """Keep the selected UI language in each employee's own session."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        language = request.session.get("ui_language", "en")
        if language not in SUPPORTED_LANGUAGES:
            language = "en"
        translation.activate(language)
        request.LANGUAGE_CODE = language
        try:
            return self.get_response(request)
        finally:
            translation.deactivate()
