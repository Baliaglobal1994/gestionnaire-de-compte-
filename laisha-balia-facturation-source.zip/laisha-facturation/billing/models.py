from decimal import Decimal, ROUND_HALF_UP

from .i18n_ui import translate_ui as tr

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models, transaction
from django.utils import timezone


CENT = Decimal("0.01")


def money(value):
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)


class CompanySettings(models.Model):
    name = models.CharField("Raison sociale", max_length=180, default="LAISHA GLOBAL")
    slug = models.SlugField(max_length=80, unique=True)
    document_prefix = models.CharField("Préfixe des documents", max_length=6, unique=True, default="LG")
    address = models.TextField("Adresse", blank=True)
    email = models.EmailField("E-mail", blank=True)
    phone = models.CharField("Téléphone", max_length=80, blank=True)
    tax_id = models.CharField("Identifiant fiscal", max_length=80, blank=True)
    website = models.URLField("Site web", blank=True)
    default_currency = models.CharField("Devise par défaut", max_length=3, choices=[("USD", "USD"), ("LRD", "LRD")], default="USD")
    footer_note = models.TextField("Note de bas de page", blank=True)
    payment_details = models.TextField("Instructions de paiement", blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Entreprise"
        verbose_name_plural = "Entreprise"

    def __str__(self):
        return self.name


class CompanyMembership(models.Model):
    class Role(models.TextChoices):
        MANAGER = "manager", "Administrateur"
        ACCOUNTANT = "accountant", "Comptable"
        EMPLOYEE = "employee", "Employé"

    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="memberships")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="company_memberships")
    role = models.CharField(max_length=12, choices=Role.choices, default=Role.EMPLOYEE)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["company", "user"], name="unique_company_member")]
        verbose_name = "Accès à une société"

    def __str__(self):
        return f"{self.user} · {self.company} ({self.get_role_display()})"


class Client(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="clients")
    name = models.CharField("Nom du client", max_length=180)
    contact_name = models.CharField("Contact", max_length=180, blank=True)
    email = models.EmailField("E-mail", blank=True)
    phone = models.CharField("Téléphone", max_length=80, blank=True)
    address = models.TextField("Adresse", blank=True)
    tax_id = models.CharField("Identifiant fiscal", max_length=80, blank=True)
    notes = models.TextField("Notes internes", blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name", "id"]
        verbose_name = "Client"

    def __str__(self):
        return self.name


class Document(models.Model):
    class Kind(models.TextChoices):
        QUOTE = "quote", "Devis"
        PROFORMA = "proforma", "Proforma"
        INVOICE = "invoice", "Facture"
        CREDIT_NOTE = "credit_note", "Avoir"

    class Status(models.TextChoices):
        DRAFT = "draft", "Brouillon"
        ISSUED = "issued", "Émis"

    class TaxTreatment(models.TextChoices):
        PENDING = "pending", "À déterminer"
        TAXABLE = "taxable", "Taxable"
        ZERO_RATED = "zero_rated", "Taux zéro"
        EXEMPT = "exempt", "Exonéré"
        OUT_OF_SCOPE = "out_of_scope", "Hors champ"

    kind = models.CharField("Type", max_length=20, choices=Kind.choices)
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="documents")
    status = models.CharField("Statut", max_length=10, choices=Status.choices, default=Status.DRAFT)
    number = models.CharField("Numéro", max_length=32, unique=True, null=True, blank=True)
    client = models.ForeignKey(Client, on_delete=models.PROTECT, related_name="documents", verbose_name="Client")
    related_invoice = models.ForeignKey("self", on_delete=models.PROTECT, related_name="credit_notes", null=True, blank=True, verbose_name="Facture concernée")
    title = models.CharField("Objet", max_length=220, blank=True)
    reference = models.CharField("Référence externe", max_length=100, blank=True)
    issue_date = models.DateField("Date", default=timezone.localdate)
    service_date = models.DateField("Date de prestation ou livraison", null=True, blank=True)
    due_date = models.DateField("Échéance", null=True, blank=True)
    currency = models.CharField("Devise", max_length=3, choices=[("USD", "USD"), ("LRD", "LRD")], default="USD")
    tax_treatment = models.CharField("Traitement fiscal", max_length=20, choices=TaxTreatment.choices, default=TaxTreatment.PENDING)
    tax_name = models.CharField("Libellé de taxe", max_length=80, blank=True)
    tax_rate = models.DecimalField("Taux de taxe (%)", max_digits=5, decimal_places=2, default=Decimal("0.00"), validators=[MinValueValidator(0), MaxValueValidator(100)])
    notes = models.TextField("Notes visibles", blank=True)
    terms = models.TextField("Conditions", blank=True)
    client_name_snapshot = models.CharField(max_length=180, blank=True)
    client_address_snapshot = models.TextField(blank=True)
    client_email_snapshot = models.EmailField(blank=True)
    client_tax_id_snapshot = models.CharField(max_length=80, blank=True)
    company_name_snapshot = models.CharField(max_length=180, blank=True)
    company_address_snapshot = models.TextField(blank=True)
    company_email_snapshot = models.EmailField(blank=True)
    company_phone_snapshot = models.CharField(max_length=80, blank=True)
    company_tax_id_snapshot = models.CharField(max_length=80, blank=True)
    company_footer_snapshot = models.TextField(blank=True)
    company_payment_snapshot = models.TextField(blank=True)
    subtotal_snapshot = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True)
    tax_amount_snapshot = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True)
    total_snapshot = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True)
    version = models.PositiveIntegerField(default=1)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="documents_created")
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="documents_issued", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    issued_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["kind", "status", "-created_at"]), models.Index(fields=["due_date"])]
        verbose_name = "Document"

    def clean(self):
        if self.client_id and self.company_id and self.client.company_id != self.company_id:
            raise ValidationError({"client": tr("Le client doit appartenir à la société sélectionnée.")})
        if self.kind == self.Kind.CREDIT_NOTE:
            if not self.related_invoice_id:
                raise ValidationError({"related_invoice": tr("Choisissez la facture concernée.")})
            if self.related_invoice.kind != self.Kind.INVOICE or self.related_invoice.status != self.Status.ISSUED:
                raise ValidationError({"related_invoice": tr("La facture concernée doit être émise.")})
            if self.currency != self.related_invoice.currency:
                raise ValidationError({"currency": tr("La devise doit correspondre à la facture.")})
            if self.client_id != self.related_invoice.client_id:
                raise ValidationError({"client": tr("Le client doit correspondre à la facture.")})
            if self.company_id and self.related_invoice.company_id != self.company_id:
                raise ValidationError({"related_invoice": tr("La facture doit appartenir à la même société.")})
            if self.tax_treatment != self.related_invoice.tax_treatment or self.tax_rate != self.related_invoice.tax_rate:
                raise ValidationError({"tax_treatment": tr("L'avoir doit reprendre le traitement fiscal et le taux de la facture.")})
        elif self.related_invoice_id:
            raise ValidationError({"related_invoice": tr("Seul un avoir peut référencer une facture.")})
        if self.due_date and self.due_date < self.issue_date:
            raise ValidationError({"due_date": tr("L'échéance doit suivre la date du document.")})
        if self.tax_treatment in {self.TaxTreatment.EXEMPT, self.TaxTreatment.OUT_OF_SCOPE, self.TaxTreatment.ZERO_RATED} and self.tax_rate != 0:
            raise ValidationError({"tax_rate": tr("Ce traitement fiscal requiert un taux de 0 %.")})
        if self.tax_treatment == self.TaxTreatment.TAXABLE and self.tax_rate <= 0:
            raise ValidationError({"tax_rate": tr("Indiquez un taux positif pour une opération taxable.")})
        if self.tax_treatment == self.TaxTreatment.TAXABLE and not self.tax_name.strip():
            raise ValidationError({"tax_name": tr("Indiquez le nom de la taxe appliquée.")})

    def save(self, *args, **kwargs):
        with transaction.atomic():
            if self.pk:
                existing = Document.objects.select_for_update().filter(pk=self.pk).first()
                if existing and existing.status == self.Status.ISSUED:
                    raise ValidationError(tr("Un document émis est immuable. Créez un avoir pour le corriger."))
            super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        with transaction.atomic():
            existing = Document.objects.select_for_update().get(pk=self.pk)
            if existing.status == self.Status.ISSUED:
                raise ValidationError(tr("Un document émis ne peut pas être supprimé."))
            super().delete(*args, **kwargs)

    @property
    def amount_subtotal(self):
        if self.subtotal_snapshot is not None:
            return self.subtotal_snapshot
        return money(sum((line.amount for line in self.lines.all()), Decimal("0")))

    @property
    def amount_tax(self):
        if self.tax_amount_snapshot is not None:
            return self.tax_amount_snapshot
        return money(self.amount_subtotal * self.tax_rate / Decimal("100"))

    @property
    def amount_total(self):
        if self.total_snapshot is not None:
            return self.total_snapshot
        return self.amount_subtotal + self.amount_tax

    @property
    def amount_paid(self):
        if self.kind != self.Kind.INVOICE:
            return Decimal("0.00")
        return money(sum((payment.amount for payment in self.payments.all() if not payment.is_reversed), Decimal("0")))

    @property
    def amount_credited(self):
        if self.kind != self.Kind.INVOICE:
            return Decimal("0.00")
        return money(sum((credit.amount_total for credit in self.credit_notes.filter(status=self.Status.ISSUED)), Decimal("0")))

    @property
    def balance(self):
        if self.kind != self.Kind.INVOICE or self.status != self.Status.ISSUED:
            return Decimal("0.00")
        return self.amount_total - self.amount_paid - self.amount_credited

    @property
    def payment_status(self):
        if self.kind != self.Kind.INVOICE or self.status != self.Status.ISSUED:
            return ""
        if self.balance <= 0:
            return "Payée" if self.balance == 0 else "Trop perçu / remboursement dû"
        if self.amount_paid > 0 or self.amount_credited > 0:
            return "Partiellement réglée"
        return "À régler"

    def __str__(self):
        return self.number or f"{self.get_kind_display()} brouillon #{self.pk or 'nouveau'}"


class DocumentLine(models.Model):
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="lines")
    position = models.PositiveIntegerField(default=0)
    description = models.CharField("Description", max_length=500)
    quantity = models.DecimalField("Quantité", max_digits=12, decimal_places=2, default=Decimal("1.00"), validators=[MinValueValidator(Decimal("0.01"))])
    unit_price = models.DecimalField("Prix unitaire", max_digits=12, decimal_places=2, default=Decimal("0.00"), validators=[MinValueValidator(0)])

    class Meta:
        ordering = ["position", "id"]
        verbose_name = "Ligne de document"

    @property
    def amount(self):
        return money(self.quantity * self.unit_price)

    def save(self, *args, **kwargs):
        with transaction.atomic():
            document = Document.objects.select_for_update().get(pk=self.document_id)
            if document.status == Document.Status.ISSUED:
                raise ValidationError(tr("Les lignes d'un document émis sont immuables."))
            if self.pk:
                original = DocumentLine.objects.select_for_update().get(pk=self.pk)
                if original.document_id != self.document_id:
                    raise ValidationError(tr("Une ligne ne peut pas changer de document."))
            super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        with transaction.atomic():
            document = Document.objects.select_for_update().get(pk=self.document_id)
            if document.status == Document.Status.ISSUED:
                raise ValidationError(tr("Les lignes d'un document émis sont immuables."))
            super().delete(*args, **kwargs)


class Payment(models.Model):
    document = models.ForeignKey(Document, on_delete=models.PROTECT, related_name="payments", verbose_name="Facture")
    account = models.ForeignKey("finance.CashAccount", on_delete=models.PROTECT, related_name="incoming_payments", null=True, blank=True, verbose_name="Compte reçu")
    amount = models.DecimalField("Montant", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    received_on = models.DateField("Date du paiement", default=timezone.localdate)
    method = models.CharField("Moyen de paiement", max_length=40, choices=[("bank", "Virement"), ("cash", "Espèces"), ("mobile", "Mobile Money"), ("card", "Carte"), ("other", "Autre")], default="bank")
    reference = models.CharField("Référence", max_length=120, blank=True)
    notes = models.TextField("Notes internes", blank=True)
    recorded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="payments_recorded")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-received_on", "-id"]
        verbose_name = "Paiement"

    def clean(self):
        if self.document_id and (self.document.kind != Document.Kind.INVOICE or self.document.status != Document.Status.ISSUED):
            raise ValidationError(tr("Les paiements concernent uniquement les factures émises."))
        if self.account_id and self.document_id and self.account.currency != self.document.currency:
            raise ValidationError({"account": tr("La devise du compte doit correspondre à la facture.")})
        if self.account_id and self.document_id and self.account.company_id != self.document.company_id:
            raise ValidationError({"account": tr("Le compte doit appartenir à la société de la facture.")})

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValidationError(tr("Un paiement enregistré est immuable. Demandez une correction à un administrateur."))
        self.full_clean()
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValidationError(tr("Un paiement enregistré ne peut pas être supprimé."))

    @property
    def is_reversed(self):
        return hasattr(self, "reversal")


class PaymentReversal(models.Model):
    payment = models.OneToOneField(Payment, on_delete=models.PROTECT, related_name="reversal", verbose_name="Paiement annulé")
    reason = models.CharField("Motif", max_length=500)
    reversed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="payment_reversals")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        verbose_name = "Annulation de paiement"

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValidationError(tr("Une annulation de paiement est immuable."))
        self.full_clean()
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValidationError(tr("Une annulation de paiement ne peut pas être supprimée."))


class NumberSequence(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="number_sequences")
    kind = models.CharField(max_length=20, choices=Document.Kind.choices)
    year = models.PositiveSmallIntegerField()
    last_number = models.PositiveIntegerField(default=0)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["company", "kind", "year"], name="unique_company_document_sequence")]


class AuditEvent(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="audit_events")
    class Action(models.TextChoices):
        CLIENT_CREATED = "client_created", "Client créé"
        CLIENT_UPDATED = "client_updated", "Client modifié"
        DOCUMENT_CREATED = "document_created", "Brouillon créé"
        DOCUMENT_UPDATED = "document_updated", "Brouillon modifié"
        DOCUMENT_ISSUED = "document_issued", "Document émis"
        PAYMENT_RECORDED = "payment_recorded", "Paiement enregistré"
        PAYMENT_REVERSED = "payment_reversed", "Paiement annulé"
        COMPANY_UPDATED = "company_updated", "Entreprise modifiée"

    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True)
    action = models.CharField(max_length=80, choices=Action.choices)
    object_type = models.CharField(max_length=80)
    object_id = models.PositiveBigIntegerField()
    details = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        verbose_name = "Journal d'audit"

    def __str__(self):
        return f"{self.action} {self.object_type} #{self.object_id}"
