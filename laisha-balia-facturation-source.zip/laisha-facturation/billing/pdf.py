"""Printable commercial documents in the employee's selected language."""

from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape

from django.conf import settings
from django.utils.translation import get_language
from bidi.algorithm import get_display
import arabic_reshaper
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Image, KeepTogether, LongTable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .models import Document


NAVY = colors.HexColor("#18314b")
GOLD = colors.HexColor("#bf8b35")
PALE = colors.HexColor("#f1f5f8")
RULE = colors.HexColor("#d5dee5")
MUTED = colors.HexColor("#526171")

PDF_LABELS = {
    "en": {"quote": "QUOTATION", "proforma": "PROFORMA INVOICE", "invoice": "INVOICE", "credit_note": "CREDIT NOTE", "draft": "DRAFT", "seller": "SELLER", "buyer": "BILL TO", "tax_id": "Tax ID", "issue_date": "Issue date", "service_date": "Supply date", "due_date": "Due date", "currency": "Currency", "reference": "Reference", "original": "Original invoice", "description": "DESCRIPTION", "quantity": "QTY", "unit_price": "UNIT PRICE", "amount": "AMOUNT", "no_items": "No items", "subtotal": "Subtotal", "total": "TOTAL", "pending": "Tax status pending", "zero": "Zero rated", "exempt": "Exempt", "outside": "Outside scope", "terms": "TERMS", "payment": "PAYMENT DETAILS", "notes": "NOTES", "page": "Page"},
    "fr": {"quote": "DEVIS", "proforma": "FACTURE PROFORMA", "invoice": "FACTURE", "credit_note": "AVOIR", "draft": "BROUILLON", "seller": "ÉMETTEUR", "buyer": "CLIENT", "tax_id": "NIF", "issue_date": "Date d’émission", "service_date": "Date de prestation", "due_date": "Échéance", "currency": "Devise", "reference": "Référence", "original": "Facture initiale", "description": "DESCRIPTION", "quantity": "QTÉ", "unit_price": "PRIX UNITAIRE", "amount": "MONTANT", "no_items": "Aucune ligne", "subtotal": "Sous-total", "total": "TOTAL", "pending": "Régime fiscal à déterminer", "zero": "Taux zéro", "exempt": "Exonéré", "outside": "Hors champ", "terms": "CONDITIONS", "payment": "PAIEMENT", "notes": "NOTES", "page": "Page"},
    "ar": {"quote": "عرض سعر", "proforma": "فاتورة أولية", "invoice": "فاتورة", "credit_note": "إشعار دائن", "draft": "مسودة", "seller": "البائع", "buyer": "العميل", "tax_id": "الرقم الضريبي", "issue_date": "تاريخ الإصدار", "service_date": "تاريخ الخدمة", "due_date": "تاريخ الاستحقاق", "currency": "العملة", "reference": "المرجع", "original": "الفاتورة الأصلية", "description": "الوصف", "quantity": "الكمية", "unit_price": "سعر الوحدة", "amount": "المبلغ", "no_items": "لا توجد بنود", "subtotal": "المجموع الفرعي", "total": "الإجمالي", "pending": "الحالة الضريبية قيد التحديد", "zero": "نسبة صفر", "exempt": "معفى", "outside": "خارج النطاق", "terms": "الشروط", "payment": "تفاصيل الدفع", "notes": "ملاحظات", "page": "صفحة"},
    "zh-hans": {"quote": "报价单", "proforma": "形式发票", "invoice": "发票", "credit_note": "贷项通知单", "draft": "草稿", "seller": "卖方", "buyer": "客户", "tax_id": "税号", "issue_date": "开具日期", "service_date": "服务日期", "due_date": "到期日期", "currency": "币种", "reference": "参考编号", "original": "原发票", "description": "描述", "quantity": "数量", "unit_price": "单价", "amount": "金额", "no_items": "暂无项目", "subtotal": "小计", "total": "合计", "pending": "税务状态待确认", "zero": "零税率", "exempt": "免税", "outside": "不在征税范围内", "terms": "条款", "payment": "付款信息", "notes": "备注", "page": "页"},
}


def _fonts(language):
    if language == "ar":
        root = Path(settings.BASE_DIR) / "billing" / "fonts"
        if "DejaVuSans" not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont("DejaVuSans", str(root / "DejaVuSans.ttf")))
            pdfmetrics.registerFont(TTFont("DejaVuSans-Bold", str(root / "DejaVuSans-Bold.ttf")))
        return "DejaVuSans", "DejaVuSans-Bold"
    if language == "zh-hans":
        if "NotoSansSC" not in pdfmetrics.getRegisteredFontNames():
            root = Path(settings.BASE_DIR) / "billing" / "fonts"
            pdfmetrics.registerFont(TTFont("NotoSansSC", str(root / "NotoSansSC-Regular.ttf")))
        return "NotoSansSC", "NotoSansSC"
    return "Helvetica", "Helvetica-Bold"


def _visual(value, language):
    value = str(value or "")
    if language == "ar":
        return get_display(arabic_reshaper.reshape(value), base_dir="R")
    return value


def _text(value, language):
    return "<br/>".join(escape(_visual(line, language)) for line in str(value or "").split("\n"))


def _money(value, currency):
    return f"{currency} {value:,.2f}"


def render_document_pdf(document):
    language = get_language() or "en"
    if language not in PDF_LABELS:
        language = "en"
    label = PDF_LABELS[language]
    font, bold_font = _fonts(language)
    alignment = 2 if language == "ar" else 0
    company = document.company
    issued = document.status == Document.Status.ISSUED
    seller_name = document.company_name_snapshot if issued else (company.name if company else "LAISHA GLOBAL")
    seller_address = document.company_address_snapshot if issued else (company.address if company else "")
    seller_email = document.company_email_snapshot if issued else (company.email if company else "")
    seller_phone = document.company_phone_snapshot if issued else (company.phone if company else "")
    seller_tax = document.company_tax_id_snapshot if issued else (company.tax_id if company else "")
    payment_details = document.company_payment_snapshot if issued else (company.payment_details if company else "")
    footer_note = document.company_footer_snapshot if issued else (company.footer_note if company else "")
    buyer_name = document.client_name_snapshot if issued else document.client.name
    buyer_address = document.client_address_snapshot if issued else document.client.address
    buyer_email = document.client_email_snapshot if issued else document.client.email
    buyer_tax = document.client_tax_id_snapshot if issued else document.client.tax_id

    titles = {kind: label[kind] for kind in (Document.Kind.QUOTE, Document.Kind.PROFORMA, Document.Kind.INVOICE, Document.Kind.CREDIT_NOTE)}
    tax_labels = {
        Document.TaxTreatment.PENDING: label["pending"],
        Document.TaxTreatment.TAXABLE: f"{document.tax_name or 'Tax'} ({document.tax_rate} %)",
        Document.TaxTreatment.ZERO_RATED: label["zero"],
        Document.TaxTreatment.EXEMPT: label["exempt"],
        Document.TaxTreatment.OUT_OF_SCOPE: label["outside"],
    }
    buffer = BytesIO()
    page_width, page_height = A4
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=19 * mm,
        rightMargin=19 * mm,
        topMargin=17 * mm,
        bottomMargin=19 * mm,
        title=f"{titles.get(document.kind, 'DOCUMENT')} {document.number or 'DRAFT'}",
        author=seller_name,
    )
    content_width = page_width - 38 * mm
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="InvoiceTitle", parent=styles["Title"], fontName=bold_font, fontSize=16, leading=22, alignment=alignment, textColor=NAVY, spaceAfter=2))
    styles.add(ParagraphStyle(name="Section", parent=styles["Normal"], fontName=bold_font, fontSize=9, leading=14, alignment=alignment, textColor=NAVY))
    styles.add(ParagraphStyle(name="Text", parent=styles["Normal"], fontName=font, fontSize=8.5, leading=14, alignment=alignment, textColor=NAVY))
    styles.add(ParagraphStyle(name="Small", parent=styles["Normal"], fontName=font, fontSize=7.5, leading=12, alignment=alignment, textColor=MUTED))
    styles.add(ParagraphStyle(name="HeaderCell", parent=styles["Normal"], fontName=bold_font, fontSize=8, leading=12, alignment=alignment, textColor=colors.white))
    styles.add(ParagraphStyle(name="RightCell", parent=styles["Text"], alignment=2))
    p = lambda s, style="Text": Paragraph(_text(s, language), styles[style])

    story = []
    logo_files = {"laisha-global": "logo-laisha-global.png", "balia-global": "logo-balia-global.webp"}
    logo_filename = logo_files.get(company.slug) if company else None
    logo_path = Path(settings.BASE_DIR) / "static" / "billing" / logo_filename if logo_filename else None
    if logo_path and logo_path.exists():
        logo = Image(str(logo_path), width=27 * mm, height=25 * mm, kind="proportional")
    else:
        logo = p(seller_name, "Section")
    header = Table([[logo, [p(titles.get(document.kind, "DOCUMENT"), "InvoiceTitle"), p(document.number or label["draft"], "Section"), p(document.title, "Small")]]], colWidths=[30 * mm, content_width - 30 * mm])
    header.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("BOTTOMPADDING", (0, 0), (-1, -1), 10)]))
    story.append(header)
    story.append(Spacer(1, 5 * mm))

    seller_bits = [p(label["seller"], "Section"), p(seller_name)]
    buyer_bits = [p(label["buyer"], "Section"), p(buyer_name)]
    for target, value in ((seller_bits, seller_address), (seller_bits, seller_email), (seller_bits, seller_phone), (buyer_bits, buyer_address), (buyer_bits, buyer_email)):
        if value:
            target.append(p(value, "Small"))
    if seller_tax:
        seller_bits.append(p(f"{label['tax_id']}: {seller_tax}", "Small"))
    if buyer_tax:
        buyer_bits.append(p(f"{label['tax_id']}: {buyer_tax}", "Small"))
    parties = Table([[seller_bits, buyer_bits]], colWidths=[content_width / 2] * 2)
    parties.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), PALE), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOX", (0, 0), (-1, -1), 0.5, RULE), ("INNERGRID", (0, 0), (-1, -1), 0.5, RULE), ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10), ("TOPPADDING", (0, 0), (-1, -1), 9), ("BOTTOMPADDING", (0, 0), (-1, -1), 9)]))
    story.extend([parties, Spacer(1, 6 * mm)])

    metadata = [
        (label["issue_date"], document.issue_date),
        (label["service_date"], document.service_date or "—"),
        (label["due_date"], document.due_date or "—"),
        (label["currency"], document.currency),
    ]
    meta_cells = [[p(label, "Small"), p(value)] for label, value in metadata]
    meta = Table([meta_cells], colWidths=[content_width / 4] * 4)
    meta.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOTTOMPADDING", (0, 0), (-1, -1), 9), ("LINEBELOW", (0, -1), (-1, -1), 0.5, RULE)]))
    story.extend([meta, Spacer(1, 4 * mm)])
    if document.reference:
        story.extend([p(f"{label['reference']}: {document.reference}", "Small"), Spacer(1, 3 * mm)])
    if document.kind == Document.Kind.CREDIT_NOTE and document.related_invoice:
        story.extend([p(f"{label['original']}: {document.related_invoice.number}", "Small"), Spacer(1, 3 * mm)])

    rows = [[p(label["description"], "HeaderCell"), p(label["quantity"], "HeaderCell"), p(label["unit_price"], "HeaderCell"), p(label["amount"], "HeaderCell")]]
    for line in document.lines.all():
        rows.append([p(line.description), p(line.quantity, "RightCell"), p(_money(line.unit_price, document.currency), "RightCell"), p(_money(line.amount, document.currency), "RightCell")])
    if len(rows) == 1:
        rows.append([p(label["no_items"], "Small"), "", "", ""])
    item_table = LongTable(rows, colWidths=[content_width * 0.48, content_width * 0.11, content_width * 0.20, content_width * 0.21], repeatRows=1, hAlign="LEFT")
    item_table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), NAVY), ("VALIGN", (0, 0), (-1, -1), "TOP"), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PALE]), ("LINEBELOW", (0, -1), (-1, -1), 0.5, RULE), ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7), ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    story.extend([item_table, Spacer(1, 5 * mm)])

    total_rows = [
        [p(label["subtotal"]), p(_money(document.amount_subtotal, document.currency), "RightCell")],
        [p(tax_labels[document.tax_treatment], "Small"), p(_money(document.amount_tax, document.currency), "RightCell")],
        [p(label["total"], "Section"), p(_money(document.amount_total, document.currency), "RightCell")],
    ]
    totals = Table(total_rows, colWidths=[content_width * 0.70, content_width * 0.30], hAlign="RIGHT")
    totals.setStyle(TableStyle([("LINEABOVE", (0, 2), (-1, 2), 1.2, GOLD), ("BACKGROUND", (0, 2), (-1, 2), PALE), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    story.extend([totals, Spacer(1, 5 * mm)])

    notes = []
    if document.terms:
        notes.extend([p(label["terms"], "Section"), p(document.terms), Spacer(1, 3 * mm)])
    if payment_details and document.kind in {Document.Kind.INVOICE, Document.Kind.PROFORMA}:
        notes.extend([p(label["payment"], "Section"), p(payment_details), Spacer(1, 3 * mm)])
    if document.notes:
        notes.extend([p(label["notes"], "Section"), p(document.notes), Spacer(1, 3 * mm)])
    if footer_note:
        notes.append(p(footer_note, "Small"))
    if notes:
        story.append(KeepTogether(notes))

    def decorate(canvas, report):
        canvas.saveState()
        canvas.setFillColor(colors.white)
        canvas.rect(0, 0, page_width, page_height, stroke=0, fill=1)
        if logo_path and logo_path.exists():
            watermark = ImageReader(str(logo_path))
            image_width, image_height = watermark.getSize()
            scale = min((116 * mm) / image_width, (95 * mm) / image_height)
            watermark_width, watermark_height = image_width * scale, image_height * scale
            canvas.saveState()
            canvas.setFillAlpha(0.075)
            canvas.drawImage(
                watermark,
                (page_width - watermark_width) / 2,
                (page_height - watermark_height) / 2,
                width=watermark_width,
                height=watermark_height,
                mask="auto",
            )
            canvas.restoreState()
        canvas.setStrokeColor(RULE)
        canvas.line(19 * mm, 15 * mm, page_width - 19 * mm, 15 * mm)
        canvas.setFont(font, 7)
        canvas.setFillColor(MUTED)
        canvas.drawString(19 * mm, 10 * mm, _visual(seller_name, language))
        canvas.drawRightString(page_width - 19 * mm, 10 * mm, _visual(f"{label['page']} {report.page}", language))
        if not issued:
            canvas.setFont(bold_font, 44)
            canvas.setFillColor(colors.HexColor("#e9edf1"))
            canvas.translate(page_width / 2, page_height / 2)
            canvas.rotate(35)
            canvas.drawCentredString(0, 0, _visual(label["draft"], language))
        canvas.restoreState()

    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buffer.getvalue()
