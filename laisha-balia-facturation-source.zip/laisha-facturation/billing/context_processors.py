from .company_context import allowed_companies
from .models import CompanyMembership
from .revision import company_revision


def company(request):
    if not request.user.is_authenticated:
        return {"company": None, "available_companies": [], "app_revision": "0:0", "can_manage_billing": False, "can_manage_finance": False}
    role = getattr(request, "company_role", None)
    active_company = getattr(request, "company", None)
    return {
        "company": active_company,
        "available_companies": allowed_companies(request.user).order_by("name"),
        "can_manage_billing": role == CompanyMembership.Role.MANAGER,
        "can_manage_finance": role in {CompanyMembership.Role.MANAGER, CompanyMembership.Role.ACCOUNTANT},
        "app_revision": company_revision(active_company),
    }
