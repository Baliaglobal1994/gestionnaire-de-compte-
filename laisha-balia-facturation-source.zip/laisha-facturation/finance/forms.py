from django import forms

from billing.form_localization import localize_form
from .models import CashAccount, CashDeposit, Expense, ExpenseCategory


class CashDepositForm(forms.ModelForm):
    class Meta:
        model = CashDeposit
        fields = ["account", "received_on", "amount", "source", "reference", "notes"]
        widgets = {
            "received_on": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["account"].queryset = CashAccount.objects.filter(company=company, active=True)
        localize_form(self)


class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ["vendor", "description", "category", "account", "expense_date", "receipt_number", "currency", "amount_before_tax", "tax_amount", "notes"]
        widgets = {
            "expense_date": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "notes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, company=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["category"].queryset = ExpenseCategory.objects.filter(company=company, active=True)
        self.fields["account"].queryset = CashAccount.objects.filter(company=company, active=True)
        localize_form(self)


class CashAccountForm(forms.ModelForm):
    class Meta:
        model = CashAccount
        fields = ["name", "kind", "currency", "opening_balance", "active"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        localize_form(self)


class ExpenseCategoryForm(forms.ModelForm):
    class Meta:
        model = ExpenseCategory
        fields = ["name", "code", "active"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        localize_form(self)
