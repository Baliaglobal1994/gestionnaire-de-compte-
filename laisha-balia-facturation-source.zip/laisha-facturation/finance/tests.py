from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import TestCase
from django.urls import reverse

from billing.models import Client, CompanyMembership, CompanySettings, Document, DocumentLine
from billing.services import issue_document, record_payment, reverse_payment

from .models import CashAccount, CashDeposit, Expense, ExpenseCategory, FinanceEvent
from .services import approve_expense, cash_position, cash_totals, record_deposit, void_deposit, void_expense


class FinanceFlowTests(TestCase):
    def setUp(self):
        user_model = get_user_model()
        self.admin = user_model.objects.create_superuser("finance_owner", "owner@example.test", "test-strong-password")
        self.employee = user_model.objects.create_user("employee", "employee@example.test", "test-strong-password")
        self.company = CompanySettings.objects.get(slug="laisha-global")
        self.other_company = CompanySettings.objects.get(slug="balia-global")
        CompanyMembership.objects.create(company=self.company, user=self.employee, role=CompanyMembership.Role.EMPLOYEE)
        self.account = CashAccount.objects.create(company=self.company, name="Main bank", currency="USD", opening_balance=Decimal("100.00"))
        self.category = ExpenseCategory.objects.create(company=self.company, name="Materials", code="600")

    def make_expense(self, *, company=None, account=None, category=None, vendor="Supplier"):
        return Expense.objects.create(
            company=company or self.company,
            vendor=vendor,
            description="Supplies",
            category=category or self.category,
            account=account or self.account,
            expense_date=date(2026, 10, 2),
            currency="USD",
            amount_before_tax=Decimal("40.00"),
            tax_amount=Decimal("4.00"),
            created_by=self.admin,
        )

    def test_expense_approval_void_and_cash_position(self):
        expense = Expense.objects.create(
            company=self.company, vendor="Supplier", description="Timber", category=self.category, account=self.account,
            expense_date=date(2026, 10, 2), receipt_number="R-1", currency="USD",
            amount_before_tax=Decimal("40.00"), tax_amount=Decimal("4.00"), created_by=self.admin,
        )
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("100.00"))
        approve_expense(expense.pk, self.admin)
        expense.refresh_from_db()
        self.assertEqual(expense.status, Expense.Status.APPROVED)
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("56.00"))
        self.assertEqual(cash_totals(self.company, date(2026, 10, 1), date(2026, 10, 31))[0]["expense"], Decimal("44.00"))
        with self.assertRaises(ValidationError):
            expense.save()
        with self.assertRaises(ValidationError):
            void_expense(expense.pk, self.admin, " ")
        void_expense(expense.pk, self.admin, "Duplicate entry")
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("100.00"))
        expense.refresh_from_db()
        self.assertEqual(expense.void_reason, "Duplicate entry")

    def test_payment_allocation_and_reversal_affect_cash_position(self):
        self.company.address = "Monrovia"
        self.company.tax_id = "TEST"
        self.company.save()
        client = Client.objects.create(company=self.company, name="Client")
        invoice = Document.objects.create(
            company=self.company, kind=Document.Kind.INVOICE, client=client, created_by=self.admin,
            issue_date=date(2026, 10, 2), service_date=date(2026, 10, 2),
            currency="USD", tax_treatment=Document.TaxTreatment.OUT_OF_SCOPE,
        )
        DocumentLine.objects.create(document=invoice, description="Service", quantity=1, unit_price=50)
        issue_document(invoice.pk, self.admin)
        payment = record_payment(invoice.pk, amount=Decimal("20.00"), received_on=date(2026, 10, 2), method="bank", reference="P-1", notes="", actor=self.admin, account=self.account)
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("120.00"))
        reverse_payment(payment.pk, reason="Mistake", actor=self.admin)
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("100.00"))

    def test_finance_requires_admin_and_csv_is_available(self):
        self.client.force_login(self.employee)
        self.assertEqual(self.client.get(reverse("finance_dashboard")).status_code, 403)
        self.assertEqual(self.client.get(reverse("expense_new")).status_code, 403)
        self.assertEqual(self.client.get(reverse("finance_export", args=["expenses"])).status_code, 403)
        self.assertEqual(self.client.post(reverse("finance_account_new"), {"name": "Unauthorized", "kind": "bank", "currency": "USD", "opening_balance": "0.00", "active": "on"}).status_code, 403)
        self.assertFalse(CashAccount.objects.filter(name="Unauthorized").exists())
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get(reverse("finance_dashboard")).status_code, 200)
        self.assertEqual(self.client.get(reverse("finance_export", args=["cashbook"])).status_code, 200)

    def test_only_accountant_or_manager_can_approve_and_void(self):
        accountant = get_user_model().objects.create_user("accountant", password="test-strong-password")
        CompanyMembership.objects.create(company=self.company, user=accountant, role=CompanyMembership.Role.ACCOUNTANT)
        expense = self.make_expense()
        with self.assertRaises(ValidationError):
            approve_expense(expense.pk, self.employee)
        self.client.force_login(self.employee)
        self.assertEqual(self.client.post(reverse("expense_approve", args=[expense.pk])).status_code, 403)
        self.client.force_login(accountant)
        self.assertEqual(self.client.post(reverse("expense_approve", args=[expense.pk])).status_code, 302)
        expense.refresh_from_db()
        self.assertEqual(expense.status, Expense.Status.APPROVED)
        self.assertEqual(expense.approved_by, accountant)
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("56.00"))
        self.client.force_login(self.employee)
        self.assertEqual(self.client.post(reverse("expense_void", args=[expense.pk]), {"reason": "Error"}).status_code, 403)
        self.client.force_login(accountant)
        self.assertEqual(self.client.post(reverse("expense_void", args=[expense.pk]), {"reason": "Error"}).status_code, 302)
        expense.refresh_from_db()
        self.assertEqual(expense.status, Expense.Status.VOID)
        self.assertEqual(expense.voided_by, accountant)
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("100.00"))
        self.assertEqual(list(FinanceEvent.objects.filter(expense=expense).values_list("action", flat=True)), ["expense_voided", "expense_approved"])

    def test_expense_status_requires_audited_service(self):
        expense = self.make_expense()
        expense.status = Expense.Status.APPROVED
        with self.assertRaises(ValidationError):
            expense.save()
        expense.refresh_from_db()
        self.assertEqual(expense.status, Expense.Status.DRAFT)
        self.assertFalse(FinanceEvent.objects.filter(expense=expense).exists())
        with self.assertRaises(ValidationError):
            Expense.objects.create(
                company=self.company, vendor="Direct", description="Direct", category=self.category,
                account=self.account, currency="USD", amount_before_tax=Decimal("1.00"),
                status=Expense.Status.APPROVED, created_by=self.admin,
            )

    def test_finance_isolation_in_forms_views_exports_and_services(self):
        other_account = CashAccount.objects.create(company=self.other_company, name="Balia bank", currency="USD")
        other_category = ExpenseCategory.objects.create(company=self.other_company, name="Balia supplies")
        own_expense = self.make_expense(vendor="Laisha supplier")
        foreign_expense = self.make_expense(
            company=self.other_company, account=other_account, category=other_category, vendor="Balia supplier"
        )
        approve_expense(foreign_expense.pk, self.admin)

        accountant = get_user_model().objects.create_user("laisha_accountant", password="test-strong-password")
        CompanyMembership.objects.create(company=self.company, user=accountant, role=CompanyMembership.Role.ACCOUNTANT)
        with self.assertRaises(ValidationError):
            approve_expense(foreign_expense.pk, accountant)
        with self.assertRaises(ValidationError):
            void_expense(foreign_expense.pk, accountant, "Correction")
        self.client.force_login(accountant)
        self.assertEqual(self.client.post(reverse("switch_company"), {"company_id": self.other_company.pk}).status_code, 404)
        self.assertEqual(self.client.get(reverse("expense_detail", args=[foreign_expense.pk])).status_code, 404)
        self.assertEqual(self.client.get(reverse("expense_edit", args=[foreign_expense.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse("expense_void", args=[foreign_expense.pk]), {"reason": "Correction"}).status_code, 404)
        self.assertEqual(self.client.get(reverse("expense_detail", args=[own_expense.pk])).status_code, 200)
        self.assertNotContains(self.client.get(reverse("expense_list")), "Balia supplier")
        self.assertNotContains(self.client.get(reverse("finance_accounts")), "Balia bank")
        self.assertNotContains(self.client.get(reverse("finance_export", args=["expenses"])), "Balia supplier")
        self.assertNotContains(self.client.get(reverse("finance_export", args=["cashbook"]), {"start": "2026-10-01", "end": "2026-10-31"}), "Balia supplier")
        invalid_form = self.client.post(reverse("expense_new"), {
            "vendor": "Attempt", "description": "Cross company", "category": other_category.pk,
            "account": other_account.pk, "expense_date": "2026-10-02", "currency": "USD",
            "amount_before_tax": "10.00", "tax_amount": "0.00",
        })
        self.assertEqual(invalid_form.status_code, 200)
        self.assertFalse(Expense.objects.filter(vendor="Attempt").exists())
        self.assertEqual(cash_totals(self.company, date(2026, 10, 1), date(2026, 10, 31)), [])

        self.client.force_login(self.admin)
        self.assertEqual(self.client.post(reverse("switch_company"), {"company_id": self.other_company.pk}).status_code, 302)
        self.assertEqual(self.client.get(reverse("expense_detail", args=[foreign_expense.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse("expense_detail", args=[own_expense.pk])).status_code, 404)
        self.assertNotContains(self.client.get(reverse("expense_list")), "Laisha supplier")
        self.assertNotContains(self.client.get(reverse("finance_export", args=["expenses"])), "Laisha supplier")

    def test_cross_company_account_and_category_cannot_be_reassigned(self):
        self.account.company = self.other_company
        with self.assertRaises(ValidationError):
            self.account.save()
        self.category.company = self.other_company
        with self.assertRaises(ValidationError):
            self.category.save()
        self.account.refresh_from_db()
        self.category.refresh_from_db()
        self.assertEqual(self.account.company, self.company)
        self.assertEqual(self.category.company, self.company)
        self.make_expense()
        self.account.currency = "LRD"
        with self.assertRaises(ValidationError):
            self.account.save()
        self.account.refresh_from_db()
        self.assertEqual(self.account.currency, "USD")

    def test_new_accounts_and_categories_create_company_scoped_events(self):
        self.client.force_login(self.admin)
        account_response = self.client.post(reverse("finance_account_new"), {
            "name": "Petty cash", "kind": "cash", "currency": "USD",
            "opening_balance": "25.00", "active": "on",
        })
        category_response = self.client.post(reverse("finance_category_new"), {
            "name": "Office", "code": "620", "active": "on",
        })
        self.assertEqual(account_response.status_code, 302)
        self.assertEqual(category_response.status_code, 302)
        self.assertEqual(
            list(FinanceEvent.objects.filter(company=self.company).order_by("pk").values_list("action", flat=True)),
            ["account_created", "category_created"],
        )
        self.assertFalse(FinanceEvent.objects.filter(company=self.other_company).exists())

    def test_money_received_updates_account_period_and_exports(self):
        self.client.force_login(self.admin)
        response = self.client.post(reverse("finance_deposit_new"), {
            "account": self.account.pk, "received_on": "2026-10-02", "amount": "75.50",
            "source": "Grant", "reference": "DEP-1", "notes": "Received in bank",
        })
        self.assertEqual(response.status_code, 302)
        deposit = CashDeposit.objects.get(company=self.company)
        self.assertEqual(deposit.status, CashDeposit.Status.RECORDED)
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("175.50"))
        self.assertEqual(cash_totals(self.company, date(2026, 10, 1), date(2026, 10, 31))[0]["income"], Decimal("75.50"))
        self.assertContains(self.client.get(reverse("finance_dashboard")), "Grant")
        self.assertContains(self.client.get(reverse("finance_deposits")), "Grant")
        self.assertContains(self.client.get(reverse("finance_export", args=["cashbook"]), {"start": "2026-10-01", "end": "2026-10-31"}), "Grant")
        self.assertContains(self.client.get(reverse("finance_export", args=["deposits"])), "DEP-1")
        self.assertIn("cash_deposits", self.client.get(reverse("export", args=["backup"])).json())
        self.assertEqual(list(deposit.events.values_list("action", flat=True)), ["deposit_recorded"])

    def test_money_received_void_is_audited_and_cannot_be_edited(self):
        deposit = record_deposit(
            company=self.company, account_id=self.account.pk, amount=Decimal("25.00"),
            received_on=date(2026, 10, 2), source="Cash received", reference="", notes="", actor=self.admin,
        )
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("125.00"))
        with self.assertRaises(ValidationError):
            deposit.amount = Decimal("500.00")
            deposit.save()
        with self.assertRaises(ValidationError):
            deposit.delete()
        void_deposit(deposit.pk, self.admin, "Duplicate")
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("100.00"))
        self.assertEqual(cash_totals(self.company, date(2026, 10, 1), date(2026, 10, 31)), [])
        self.assertEqual(list(FinanceEvent.objects.filter(deposit=deposit).values_list("action", flat=True)), ["deposit_voided", "deposit_recorded"])
        with self.assertRaises(ValidationError):
            void_deposit(deposit.pk, self.admin, "Again")

    def test_money_received_respects_company_and_role(self):
        foreign_account = CashAccount.objects.create(company=self.other_company, name="Balia funds", currency="USD")
        with self.assertRaises(ValidationError):
            record_deposit(company=self.company, account_id=foreign_account.pk, amount=Decimal("10.00"), received_on=date(2026, 10, 2), source="Wrong company", reference="", notes="", actor=self.admin)
        with self.assertRaises(ValidationError):
            record_deposit(company=self.company, account_id=self.account.pk, amount=Decimal("10.00"), received_on=date(2026, 10, 2), source="Employee", reference="", notes="", actor=self.employee)
        self.client.force_login(self.employee)
        self.assertEqual(self.client.get(reverse("finance_deposits")).status_code, 403)
        self.assertEqual(self.client.post(reverse("finance_deposit_new"), {"account": self.account.pk, "amount": "10.00", "source": "Employee"}).status_code, 403)
        self.client.force_login(self.admin)
        invalid = self.client.post(reverse("finance_deposit_new"), {
            "account": foreign_account.pk, "received_on": "2026-10-02", "amount": "10.00", "source": "Wrong company",
        })
        self.assertEqual(invalid.status_code, 200)
        self.assertFalse(CashDeposit.objects.exists())
        balia_deposit = record_deposit(company=self.other_company, account_id=foreign_account.pk, amount=Decimal("10.00"), received_on=date(2026, 10, 2), source="Balia only", reference="", notes="", actor=self.admin)
        accountant = get_user_model().objects.create_user("deposit_accountant", password="test-strong-password")
        CompanyMembership.objects.create(company=self.company, user=accountant, role=CompanyMembership.Role.ACCOUNTANT)
        with self.assertRaises(ValidationError):
            void_deposit(balia_deposit.pk, accountant, "Wrong company")
        with self.assertRaises(ValidationError):
            record_deposit(company=self.other_company, account_id=foreign_account.pk, amount=Decimal("1.00"), received_on=date(2026, 10, 2), source="Wrong company", reference="", notes="", actor=accountant)
        self.assertEqual(self.client.get(reverse("finance_deposit_detail", args=[balia_deposit.pk])).status_code, 404)
        self.assertNotContains(self.client.get(reverse("finance_deposits")), "Balia only")
        self.assertNotContains(self.client.get(reverse("finance_export", args=["deposits"])), "Balia only")
        self.assertEqual(self.client.post(reverse("finance_deposit_void", args=[balia_deposit.pk]), {"reason": "Wrong"}).status_code, 404)
        self.assertEqual(cash_position(self.company)[0]["balance"], Decimal("100.00"))
        self.assertEqual(cash_position(self.other_company)[0]["balance"], Decimal("10.00"))
