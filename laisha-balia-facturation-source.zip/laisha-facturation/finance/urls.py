from django.urls import path

from . import views

urlpatterns = [
    path("", views.dashboard, name="finance_dashboard"),
    path("deposits/", views.deposit_list, name="finance_deposits"),
    path("deposits/new/", views.deposit_new, name="finance_deposit_new"),
    path("deposits/<int:pk>/", views.deposit_detail, name="finance_deposit_detail"),
    path("deposits/<int:pk>/void/", views.deposit_void, name="finance_deposit_void"),
    path("expenses/", views.expense_list, name="expense_list"),
    path("expenses/new/", views.expense_new, name="expense_new"),
    path("expenses/<int:pk>/", views.expense_detail, name="expense_detail"),
    path("expenses/<int:pk>/edit/", views.expense_edit, name="expense_edit"),
    path("expenses/<int:pk>/approve/", views.expense_approve, name="expense_approve"),
    path("expenses/<int:pk>/void/", views.expense_void, name="expense_void"),
    path("accounts/", views.account_list, name="finance_accounts"),
    path("accounts/new/", views.account_new, name="finance_account_new"),
    path("categories/new/", views.category_new, name="finance_category_new"),
    path("export/<str:kind>/", views.export_data, name="finance_export"),
]
