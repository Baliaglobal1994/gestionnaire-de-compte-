from decimal import Decimal

from billing.i18n_ui import translate_ui as tr

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models, transaction
from django.utils import timezone

from billing.models import CompanySettings, money


class ExpenseCategory(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="expense_categories")
    name = models.CharField("Catégorie", max_length=120)
    code = models.CharField("Code comptable", max_length=30, blank=True)
    active = models.BooleanField("Active", default=True)

    class Meta:
        ordering = ["name"]
        verbose_name = "Catégorie de dépense"
        constraints = [models.UniqueConstraint(fields=["company", "name"], name="unique_company_expense_category")]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if self.pk and ExpenseCategory.objects.filter(pk=self.pk).exclude(company_id=self.company_id).exists():
            raise ValidationError(tr("La société d'une catégorie ne peut pas être modifiée."))
        super().save(*args, **kwargs)


class CashAccount(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="cash_accounts")
    class Kind(models.TextChoices):
        BANK = "bank", "Banque"
        CASH = "cash", "Caisse"
        MOBILE = "mobile", "Mobile Money"

    name = models.CharField("Compte", max_length=120)
    kind = models.CharField("Type", max_length=10, choices=Kind.choices, default=Kind.BANK)
    currency = models.CharField("Devise", max_length=3, choices=[("USD", "USD"), ("LRD", "LRD")])
    opening_balance = models.DecimalField("Solde initial", max_digits=14, decimal_places=2, default=Decimal("0.00"))
    active = models.BooleanField("Actif", default=True)

    class Meta:
        ordering = ["name", "id"]
        constraints = [models.UniqueConstraint(fields=["company", "name", "currency"], name="unique_company_cash_account_currency")]
        verbose_name = "Compte de trésorerie"

    def __str__(self):
        return f"{self.name} ({self.currency})"

    def save(self, *args, **kwargs):
        if self.pk:
            previous = CashAccount.objects.get(pk=self.pk)
            if previous.company_id != self.company_id:
                raise ValidationError(tr("La société d'un compte ne peut pas être modifiée."))
            if previous.currency != self.currency and (self.expenses.exists() or self.incoming_payments.exists() or self.deposits.exists()):
                raise ValidationError(tr("La devise d'un compte utilisé ne peut pas être modifiée."))
        super().save(*args, **kwargs)


class CashDeposit(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="cash_deposits")
    account = models.ForeignKey(CashAccount, on_delete=models.PROTECT, related_name="deposits", verbose_name="Compte reçu")
    received_on = models.DateField("Date du dépôt", default=timezone.localdate)
    amount = models.DecimalField("Montant", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    source = models.CharField("Provenance", max_length=180)
    reference = models.CharField("Référence", max_length=120, blank=True)
    notes = models.TextField("Notes internes", blank=True)
    class Status(models.TextChoices):
        RECORDED = "recorded", "Enregistré"
        VOID = "void", "Annulé"

    status = models.CharField("Statut", max_length=10, choices=Status.choices, default=Status.RECORDED)
    recorded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="cash_deposits_recorded")
    voided_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="cash_deposits_voided", null=True, blank=True)
    void_reason = models.CharField("Motif d'annulation", max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    voided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-received_on", "-id"]
        indexes = [models.Index(fields=["company", "status", "received_on"])]
        verbose_name = "Entrée de fonds"

    def clean(self):
        if self.company_id and self.account_id and self.account.company_id != self.company_id:
            raise ValidationError({"account": tr("Le compte doit appartenir à la même société.")})
        if self.account_id and not self.account.active:
            raise ValidationError({"account": tr("Le compte doit être actif.")})
        if self.amount is not None and self.amount <= 0:
            raise ValidationError({"amount": tr("Le montant doit être positif.")})
        if not (self.source or "").strip():
            raise ValidationError({"source": tr("Indiquez la provenance des fonds.")})

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValidationError(tr("Une entrée de fonds enregistrée ne peut pas être modifiée."))
        if self.status != self.Status.RECORDED:
            raise ValidationError(tr("Une nouvelle entrée de fonds doit être enregistrée."))
        self.full_clean()
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValidationError(tr("Une entrée de fonds ne peut pas être supprimée ; annulez-la avec un motif."))

    def __str__(self):
        return f"{self.source} · {self.account.currency} {self.amount}"


class Expense(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="expenses")
    class Status(models.TextChoices):
        DRAFT = "draft", "Brouillon"
        APPROVED = "approved", "Validée"
        VOID = "void", "Annulée"

    vendor = models.CharField("Fournisseur", max_length=180)
    description = models.CharField("Description", max_length=300)
    category = models.ForeignKey(ExpenseCategory, on_delete=models.PROTECT, related_name="expenses", verbose_name="Catégorie")
    account = models.ForeignKey(CashAccount, on_delete=models.PROTECT, related_name="expenses", verbose_name="Compte payé")
    expense_date = models.DateField("Date de dépense", default=timezone.localdate)
    receipt_number = models.CharField("Référence du justificatif", max_length=120, blank=True)
    currency = models.CharField("Devise", max_length=3, choices=[("USD", "USD"), ("LRD", "LRD")])
    amount_before_tax = models.DecimalField("Montant hors taxe", max_digits=14, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    tax_amount = models.DecimalField("Taxe payée", max_digits=14, decimal_places=2, default=Decimal("0.00"), validators=[MinValueValidator(0)])
    status = models.CharField("Statut", max_length=10, choices=Status.choices, default=Status.DRAFT)
    notes = models.TextField("Notes internes", blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="expenses_created")
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="expenses_approved", null=True, blank=True)
    voided_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="expenses_voided", null=True, blank=True)
    void_reason = models.CharField("Motif d'annulation", max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    voided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-expense_date", "-id"]
        indexes = [models.Index(fields=["status", "expense_date", "currency"])]
        verbose_name = "Dépense"

    @property
    def amount_total(self):
        return money(self.amount_before_tax + self.tax_amount)

    def clean(self):
        if self.company_id and self.account_id and self.account.company_id != self.company_id:
            raise ValidationError({"account": tr("Le compte doit appartenir à la même société.")})
        if self.company_id and self.category_id and self.category.company_id != self.company_id:
            raise ValidationError({"category": tr("La catégorie doit appartenir à la même société.")})
        if self.account_id and self.currency != self.account.currency:
            raise ValidationError({"currency": tr("La devise doit correspondre au compte de trésorerie.")})
        if self.amount_before_tax is not None and self.amount_before_tax <= 0:
            raise ValidationError({"amount_before_tax": tr("Le montant doit être positif.")})
        if self.tax_amount is not None and self.tax_amount < 0:
            raise ValidationError({"tax_amount": tr("La taxe ne peut pas être négative.")})

    def save(self, *args, **kwargs):
        with transaction.atomic():
            if self.pk:
                previous = Expense.objects.select_for_update().get(pk=self.pk)
                if previous.status != self.Status.DRAFT:
                    raise ValidationError(tr("Une dépense validée ou annulée ne peut pas être modifiée."))
                if self.status != self.Status.DRAFT:
                    raise ValidationError(tr("Validez la dépense avec le parcours de validation et son journal."))
            elif self.status != self.Status.DRAFT:
                raise ValidationError(tr("Une nouvelle dépense doit être enregistrée comme brouillon."))
            self.full_clean()
            super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValidationError(tr("Une dépense ne peut pas être supprimée ; annulez-la avec un motif."))

    def __str__(self):
        return f"{self.vendor} · {self.currency} {self.amount_total}"


class FinanceEvent(models.Model):
    company = models.ForeignKey(CompanySettings, on_delete=models.PROTECT, related_name="finance_events")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    action = models.CharField(max_length=40)
    expense = models.ForeignKey(Expense, on_delete=models.PROTECT, related_name="events", null=True, blank=True)
    deposit = models.ForeignKey(CashDeposit, on_delete=models.PROTECT, related_name="events", null=True, blank=True)
    details = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        verbose_name = "Journal financier"
