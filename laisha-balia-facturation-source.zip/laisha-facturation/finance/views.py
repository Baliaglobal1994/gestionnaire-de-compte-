"""Accountant-facing cashbook and expense workflow."""

from datetime import date
from functools import wraps

from billing.i18n_ui import translate_ui as tr

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from billing.models import Payment
from billing.views import _csv_response

from .forms import CashAccountForm, CashDepositForm, ExpenseCategoryForm, ExpenseForm
from .models import CashAccount, CashDeposit, Expense, ExpenseCategory, FinanceEvent
from .services import approve_expense, cash_position, cash_totals, record_deposit, void_deposit, void_expense


def finance_required(view):
    @login_required
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        if request.company_role not in {"manager", "accountant"}:
            raise PermissionDenied(tr("Accès réservé à l'administration et à la comptabilité."))
        return view(request, *args, **kwargs)
    return wrapped


def _period(request):
    today = timezone.localdate()
    default_start = today.replace(day=1)
    try:
        start = date.fromisoformat(request.GET.get("start", ""))
    except ValueError:
        start = default_start
    try:
        end = date.fromisoformat(request.GET.get("end", ""))
    except ValueError:
        end = today
    if end < start:
        end = start
    return start, end


@finance_required
def dashboard(request):
    start, end = _period(request)
    return render(request, "finance/dashboard.html", {
        "start": start,
        "end": end,
        "totals": cash_totals(request.company, start, end),
        "accounts": cash_position(request.company),
        "recent_expenses": Expense.objects.select_related("category", "account").filter(company=request.company)[:10],
        "recent_deposits": CashDeposit.objects.select_related("account").filter(company=request.company)[:10],
        "unallocated_receipts": Payment.objects.filter(document__company=request.company, reversal__isnull=True, account__isnull=True).count(),
    })


@finance_required
def deposit_list(request):
    deposits = CashDeposit.objects.select_related("account", "recorded_by").filter(company=request.company)
    return render(request, "finance/deposit_list.html", {"deposits": deposits[:300]})


@finance_required
def deposit_new(request):
    form = CashDepositForm(request.POST or None, company=request.company)
    if request.method == "POST" and form.is_valid():
        try:
            deposit = record_deposit(
                company=request.company, account_id=form.cleaned_data["account"].pk,
                amount=form.cleaned_data["amount"], received_on=form.cleaned_data["received_on"],
                source=form.cleaned_data["source"], reference=form.cleaned_data["reference"],
                notes=form.cleaned_data["notes"], actor=request.user,
            )
        except ValidationError as error:
            form.add_error(None, error)
        else:
            messages.success(request, tr("Entrée de fonds enregistrée et ajoutée au solde du compte."))
            return redirect("finance_deposit_detail", pk=deposit.pk)
    return render(request, "finance/deposit_form.html", {
        "form": form,
        "accounts_available": CashAccount.objects.filter(company=request.company, active=True).exists(),
    })


@finance_required
def deposit_detail(request, pk):
    deposit = get_object_or_404(
        CashDeposit.objects.select_related("account", "recorded_by", "voided_by"),
        pk=pk, company=request.company,
    )
    return render(request, "finance/deposit_detail.html", {"deposit": deposit})


@finance_required
@require_POST
def deposit_void(request, pk):
    get_object_or_404(CashDeposit, pk=pk, company=request.company)
    try:
        void_deposit(pk, request.user, request.POST.get("reason", ""))
        messages.success(request, tr("Entrée de fonds annulée ; le solde du compte a été recalculé."))
    except ValidationError as error:
        messages.error(request, " ".join(error.messages))
    return redirect("finance_deposit_detail", pk=pk)


@finance_required
def expense_list(request):
    expenses = Expense.objects.select_related("category", "account", "created_by").filter(company=request.company)
    status = request.GET.get("status", "")
    if status in Expense.Status.values:
        expenses = expenses.filter(status=status)
    return render(request, "finance/expense_list.html", {"expenses": expenses[:300], "status": status})


@finance_required
def expense_new(request):
    form = ExpenseForm(request.POST or None, company=request.company)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            expense = form.save(commit=False)
            expense.company = request.company
            expense.created_by = request.user
            expense.save()
            FinanceEvent.objects.create(company=request.company, actor=request.user, action="expense_created", expense=expense)
        messages.success(request, tr("Brouillon de dépense enregistré."))
        return redirect("expense_detail", pk=expense.pk)
    return render(request, "finance/expense_form.html", {"form": form, "expense": None})


@finance_required
def expense_edit(request, pk):
    expense = get_object_or_404(Expense, pk=pk, company=request.company)
    if expense.status != Expense.Status.DRAFT:
        raise PermissionDenied(tr("Seuls les brouillons de dépenses sont modifiables."))
    form = ExpenseForm(request.POST or None, instance=expense, company=request.company)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            form.save()
            FinanceEvent.objects.create(company=request.company, actor=request.user, action="expense_updated", expense=expense)
        messages.success(request, tr("Dépense mise à jour."))
        return redirect("expense_detail", pk=expense.pk)
    return render(request, "finance/expense_form.html", {"form": form, "expense": expense})


@finance_required
def expense_detail(request, pk):
    expense = get_object_or_404(Expense.objects.select_related("category", "account", "created_by", "approved_by", "voided_by"), pk=pk, company=request.company)
    return render(request, "finance/expense_detail.html", {"expense": expense})


@finance_required
@require_POST
def expense_approve(request, pk):
    get_object_or_404(Expense, pk=pk, company=request.company)
    try:
        approve_expense(pk, request.user)
        messages.success(request, tr("Dépense validée et ajoutée au livre de trésorerie."))
    except ValidationError as error:
        messages.error(request, " ".join(error.messages))
    return redirect("expense_detail", pk=pk)


@finance_required
@require_POST
def expense_void(request, pk):
    get_object_or_404(Expense, pk=pk, company=request.company)
    try:
        void_expense(pk, request.user, request.POST.get("reason", ""))
        messages.success(request, tr("Dépense annulée ; l'écriture reste dans l'historique."))
    except ValidationError as error:
        messages.error(request, " ".join(error.messages))
    return redirect("expense_detail", pk=pk)


@finance_required
def account_list(request):
    return render(request, "finance/account_list.html", {
        "accounts": cash_position(request.company),
        "categories": ExpenseCategory.objects.filter(company=request.company),
    })


@finance_required
def account_new(request):
    form = CashAccountForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            account = form.save(commit=False)
            account.company = request.company
            account.save()
            FinanceEvent.objects.create(
                company=request.company, actor=request.user, action="account_created",
                details={"account_id": account.pk, "name": account.name, "currency": account.currency},
            )
        messages.success(request, tr("Compte ajouté."))
        return redirect("finance_accounts")
    return render(request, "finance/simple_form.html", {"form": form, "title": "Nouveau compte de trésorerie"})


@finance_required
def category_new(request):
    form = ExpenseCategoryForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            category = form.save(commit=False)
            category.company = request.company
            category.save()
            FinanceEvent.objects.create(
                company=request.company, actor=request.user, action="category_created",
                details={"category_id": category.pk, "name": category.name},
            )
        messages.success(request, tr("Catégorie ajoutée."))
        return redirect("finance_accounts")
    return render(request, "finance/simple_form.html", {"form": form, "title": "Nouvelle catégorie de dépense"})


@finance_required
@require_GET
def export_data(request, kind):
    if kind == "deposits":
        rows = (
            (d.id, d.received_on, d.source, d.account.name, d.account.currency, d.amount,
             d.reference, d.status, d.void_reason, d.recorded_by.username,
             d.voided_by.username if d.voided_by else "")
            for d in CashDeposit.objects.select_related("account", "recorded_by", "voided_by")
            .filter(company=request.company).order_by("received_on", "id")
        )
        return _csv_response(f"{request.company.slug}-entrees-fonds.csv", ["ID", "Date", "Provenance", "Compte", "Devise", "Montant", "Référence", "Statut", "Motif annulation", "Enregistré par", "Annulé par"], rows)
    if kind == "expenses":
        rows = (
            (e.id, e.expense_date, e.vendor, e.description, e.category.code, e.category.name, e.account.name, e.currency,
             e.amount_before_tax, e.tax_amount, e.amount_total, e.receipt_number, e.status, e.void_reason, e.created_by.username,
             e.approved_by.username if e.approved_by else "")
            for e in Expense.objects.select_related("category", "account", "created_by", "approved_by").filter(company=request.company).order_by("expense_date", "id")
        )
        return _csv_response("laisha-depenses.csv", ["ID", "Date", "Fournisseur", "Description", "Code", "Catégorie", "Compte", "Devise", "Hors taxe", "Taxe payée", "Total", "Justificatif", "Statut", "Motif annulation", "Créé par", "Validé par"], rows)
    if kind == "cashbook":
        start, end = _period(request)
        entries = []
        for p in Payment.objects.select_related("document", "account").filter(document__company=request.company, reversal__isnull=True, received_on__gte=start, received_on__lte=end):
            entries.append((p.received_on, "Recette", p.document.number, p.document.client_name_snapshot, p.account.name if p.account else "Non affecté", p.document.currency, p.amount, "", p.reference))
        for d in CashDeposit.objects.select_related("account").filter(company=request.company, status=CashDeposit.Status.RECORDED, received_on__gte=start, received_on__lte=end):
            entries.append((d.received_on, "Entrée de fonds", d.reference, d.source, d.account.name, d.account.currency, d.amount, "", d.notes))
        for e in Expense.objects.select_related("account").filter(company=request.company, status=Expense.Status.APPROVED, expense_date__gte=start, expense_date__lte=end):
            entries.append((e.expense_date, "Dépense", e.receipt_number, e.vendor, e.account.name, e.currency, "", e.amount_total, e.description))
        entries.sort(key=lambda row: (row[0], row[1], str(row[2])))
        return _csv_response("laisha-livre-tresorerie.csv", ["Date", "Nature", "Document", "Tiers", "Compte", "Devise", "Entrée", "Sortie", "Référence ou description"], entries)
    raise Http404(tr("Export inconnu."))
