from collections import defaultdict
from decimal import Decimal

from billing.i18n_ui import translate_ui as tr

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import F
from django.utils import timezone

from billing.models import CompanyMembership, Payment, money

from .models import CashAccount, CashDeposit, Expense, FinanceEvent


def _require_finance_role(company, actor):
    if not actor.is_superuser and not CompanyMembership.objects.filter(
        user=actor, company=company,
        role__in=[CompanyMembership.Role.MANAGER, CompanyMembership.Role.ACCOUNTANT],
    ).exists():
        raise ValidationError(tr("Accès réservé à la comptabilité de cette société."))


@transaction.atomic
def record_deposit(*, company, account_id, amount, received_on, source, reference, notes, actor):
    _require_finance_role(company, actor)
    account = CashAccount.objects.select_for_update().filter(pk=account_id, company=company, active=True).first()
    if account is None:
        raise ValidationError(tr("Choisissez un compte actif de cette société."))
    deposit = CashDeposit(
        company=company, account=account, amount=amount, received_on=received_on,
        source=(source or "").strip(), reference=(reference or "").strip(), notes=(notes or "").strip(), recorded_by=actor,
    )
    deposit.save()
    FinanceEvent.objects.create(
        company=company, actor=actor, action="deposit_recorded", deposit=deposit,
        details={"account_id": account.pk, "amount": str(deposit.amount), "currency": account.currency},
    )
    return deposit


@transaction.atomic
def void_deposit(deposit_id, actor, reason):
    reason = (reason or "").strip()
    if not reason or len(reason) > 500:
        raise ValidationError(tr("Indiquez un motif d'annulation de 1 à 500 caractères."))
    deposit = CashDeposit.objects.select_for_update().select_related("account", "company").get(pk=deposit_id)
    _require_finance_role(deposit.company, actor)
    if deposit.status != CashDeposit.Status.RECORDED:
        raise ValidationError(tr("Cette entrée de fonds est déjà annulée."))
    CashDeposit.objects.filter(pk=deposit.pk, status=CashDeposit.Status.RECORDED).update(
        status=CashDeposit.Status.VOID, voided_by=actor, voided_at=timezone.now(), void_reason=reason,
    )
    FinanceEvent.objects.create(
        company=deposit.company, actor=actor, action="deposit_voided", deposit=deposit,
        details={"reason": reason, "account_id": deposit.account_id, "amount": str(deposit.amount), "currency": deposit.account.currency},
    )
    deposit.refresh_from_db()
    return deposit


@transaction.atomic
def approve_expense(expense_id, actor):
    expense = Expense.objects.select_for_update().select_related("account", "category").get(pk=expense_id)
    if not actor.is_superuser and not CompanyMembership.objects.filter(user=actor, company=expense.company, role__in=[CompanyMembership.Role.MANAGER, CompanyMembership.Role.ACCOUNTANT]).exists():
        raise ValidationError(tr("Accès réservé à la comptabilité de cette société."))
    if expense.status != Expense.Status.DRAFT:
        raise ValidationError(tr("Cette dépense n'est plus un brouillon."))
    expense.full_clean()
    if not expense.account.active or not expense.category.active:
        raise ValidationError(tr("Le compte et la catégorie doivent être actifs."))
    Expense.objects.filter(pk=expense.pk, status=Expense.Status.DRAFT).update(
        status=Expense.Status.APPROVED, approved_by=actor, approved_at=timezone.now()
    )
    FinanceEvent.objects.create(company=expense.company, actor=actor, action="expense_approved", expense=expense, details={"total": str(expense.amount_total), "currency": expense.currency})
    expense.refresh_from_db()
    return expense


@transaction.atomic
def void_expense(expense_id, actor, reason):
    reason = (reason or "").strip()
    if not reason or len(reason) > 500:
        raise ValidationError(tr("Indiquez un motif d'annulation de 1 à 500 caractères."))
    expense = Expense.objects.select_for_update().get(pk=expense_id)
    if not actor.is_superuser and not CompanyMembership.objects.filter(user=actor, company=expense.company, role__in=[CompanyMembership.Role.MANAGER, CompanyMembership.Role.ACCOUNTANT]).exists():
        raise ValidationError(tr("Accès réservé à la comptabilité de cette société."))
    if expense.status != Expense.Status.APPROVED:
        raise ValidationError(tr("Seule une dépense validée peut être annulée."))
    Expense.objects.filter(pk=expense.pk, status=Expense.Status.APPROVED).update(
        status=Expense.Status.VOID, voided_by=actor, voided_at=timezone.now(), void_reason=reason
    )
    FinanceEvent.objects.create(company=expense.company, actor=actor, action="expense_voided", expense=expense, details={"reason": reason, "total": str(expense.amount_total), "currency": expense.currency})
    expense.refresh_from_db()
    return expense


def cash_position(company):
    """Book balances only: opening balance + payments + deposits - approved expenses."""
    result = []
    for account in CashAccount.objects.filter(company=company):
        receipts = sum((p.amount for p in Payment.objects.filter(account=account, document__company=company, reversal__isnull=True)), Decimal("0"))
        receipts += sum((d.amount for d in CashDeposit.objects.filter(company=company, account=account, status=CashDeposit.Status.RECORDED)), Decimal("0"))
        spending = sum((e.amount_total for e in Expense.objects.filter(company=company, account=account, status=Expense.Status.APPROVED)), Decimal("0"))
        result.append({"account": account, "receipts": money(receipts), "spending": money(spending), "balance": money(account.opening_balance + receipts - spending)})
    return result


def cash_totals(company, start, end):
    """Cash-basis payments, deposits and expenses, kept separate by currency."""
    totals = defaultdict(lambda: {"income": Decimal("0.00"), "expense": Decimal("0.00")})
    receipts = Payment.objects.select_related("document").filter(document__company=company, reversal__isnull=True, received_on__gte=start, received_on__lte=end)
    expenses = Expense.objects.filter(company=company, status=Expense.Status.APPROVED, expense_date__gte=start, expense_date__lte=end)
    deposits = CashDeposit.objects.select_related("account").filter(company=company, status=CashDeposit.Status.RECORDED, received_on__gte=start, received_on__lte=end)
    for payment in receipts:
        totals[payment.document.currency]["income"] += payment.amount
    for deposit in deposits:
        totals[deposit.account.currency]["income"] += deposit.amount
    for expense in expenses:
        totals[expense.currency]["expense"] += expense.amount_total
    return [
        {"currency": currency, "income": money(values["income"]), "expense": money(values["expense"]), "net": money(values["income"] - values["expense"])}
        for currency, values in sorted(totals.items())
    ]
