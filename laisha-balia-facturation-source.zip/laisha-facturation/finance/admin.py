from django.contrib import admin

from .models import CashAccount, CashDeposit, Expense, ExpenseCategory, FinanceEvent


@admin.register(CashAccount)
class CashAccountAdmin(admin.ModelAdmin):
    list_display = ("name", "kind", "currency", "opening_balance", "active")
    search_fields = ("name",)


@admin.register(ExpenseCategory)
class ExpenseCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "active")
    search_fields = ("name", "code")


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ("vendor", "expense_date", "currency", "amount_before_tax", "tax_amount", "status")
    list_filter = ("status", "currency", "category")
    search_fields = ("vendor", "description", "receipt_number")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(CashDeposit)
class CashDepositAdmin(admin.ModelAdmin):
    list_display = ("source", "received_on", "account", "amount", "status")
    list_filter = ("status", "account__company")
    search_fields = ("source", "reference")
    readonly_fields = ("company", "account", "received_on", "amount", "source", "reference", "notes", "status", "recorded_by", "voided_by", "void_reason", "created_at", "voided_at")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(FinanceEvent)
class FinanceEventAdmin(admin.ModelAdmin):
    list_display = ("action", "expense", "deposit", "actor", "created_at")
    readonly_fields = ("actor", "action", "expense", "deposit", "details", "created_at")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
